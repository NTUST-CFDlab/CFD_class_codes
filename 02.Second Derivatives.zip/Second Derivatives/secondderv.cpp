#include <iostream>
#include <fstream>
#include <cmath>

//using namespace std;

int main() {
    const int m = 10000;
    double dx, fa, discrepancy, sum, error;
    double x[m+1], func[m+1], d2fdx2[m];

    dx = 2.0 / m;
    x[0] = -1.0;
    func[0] = 3.0 * x[0] * x[0] * x[0] + 2.0 * x[0] * x[0] + 6.0 * x[0] + 20.0;

    std::ofstream file("002_cpp.dat");
    // file << x[0] << " " << func[0] << std::endl;

    for (int i = 1; i <= m; i++) {
        x[i] = x[i-1] + dx;
        func[i] = 3.0 * x[i] * x[i] * x[i] + 2.0 * x[i] * x[i] + 6.0 * x[i] + 20.0;
        // file << x[i] << " " << func[i] << std::endl;
    }

    sum = 0.0;
    for (int i = 1; i < m; i++) {
        fa = 18.0 * x[i] + 4.0;
        d2fdx2[i] = (func[i+1] - 2.0 * func[i] + func[i-1]) / (dx * dx);
        discrepancy = d2fdx2[i] - fa;
        sum += discrepancy * discrepancy;
        file << x[i] << " " << func[i] << " " << discrepancy << std::endl;
    }

    file.close();
    error = sqrt(sum) / m;

    std::cout << m << " " << error << std::endl;

    return 0;
}
