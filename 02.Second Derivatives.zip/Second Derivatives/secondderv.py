import math

m = 10000
dx = 2.0 / m
x = [0.0] * (m + 1)
func = [0.0] * (m + 1)
d2fdx2 = [0.0] * m

x[0] = -1.0
func[0] = 3.0 * x[0] ** 3 + 2.0 * x[0] ** 2 + 6.0 * x[0] + 20.0

with open('002.dat', 'w') as file:
    for i in range(1, m + 1):
        x[i] = x[i - 1] + dx
        func[i] = 3.0 * x[i] ** 3 + 2.0 * x[i] ** 2 + 6.0 * x[i] + 20.0

    sum_val = 0.0
    for i in range(1, m):
        fa = 18.0 * x[i] + 4.0
        d2fdx2[i] = (func[i + 1] - 2.0 * func[i] + func[i - 1]) / (dx ** 2)
        discrepancy = d2fdx2[i] - fa
        sum_val += discrepancy ** 2
        file.write(f"{x[i]}, {func[i]}, {discrepancy}\n")

    error = math.sqrt(sum_val) / m
    print(m, error)
