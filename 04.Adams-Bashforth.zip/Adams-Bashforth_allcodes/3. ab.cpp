#include <iostream>
#include <fstream>
#include <iomanip>      // std::setprecision
#include <cmath>

using namespace std;

const int m = 1000;
const long double dt = 0.001;

int main()
{
    int i;
    double time, discrepancy, xa;
    double x = 5.7, x1, tx;
    time = 0.0;
    time = time + dt;
    x1 = x;
    x = x + dt * (3.0 * x);
    ofstream outFile("ab.dat");
    for (i = 2; i <= m; i++) {
        time = time + dt;
        tx = x;
        x = x + dt * (1.5 * (3.0 * x) - 0.5 * (3.0 * x1));
        x1 = tx;
        xa = 5.7 * exp(3.0 * time);
        outFile << setprecision(15) << time << " " << setprecision(15) << x << " " << setprecision(15) << xa << endl;
    }
    discrepancy = x - xa;
    cout << time << " " << x << " " << xa << " " << discrepancy << endl;
    outFile.close();
    return 0;
}
