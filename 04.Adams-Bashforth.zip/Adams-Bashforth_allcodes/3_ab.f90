program AB
implicit none
integer, parameter :: m = 1000
integer :: i
double precision, parameter :: dt = 0.0001d0
double precision :: time, discrepancy, xa
double precision :: x, x1,tx


x=5.7d0

time=0.d0

time=time+dt
x1=x
x=x+dt*(3.d0*x)
open(unit=11, file='ab.dat')

do i = 2, m
   time=time+dt
   tx=x
   x=x+dt*(1.5d0*(3.0d0*x)-0.5d0*(3.0d0*x1))
   x1=tx
   xa=5.7d0*dexp(3.d0*time)
   write(11,*)time, x, xa
end do
discrepancy=x-xa
write(*,*)time,x, xa, discrepancy
close(11)
end program AB