# ---------------------------------------
# This program is to calculate using the Adam Basforth method
# ---------------------------------------

# Import
import math

# Main Parameter
m = 1000
dt = 0.001
time = 0.0
x = 5.7

# Main Loop
time = time + dt
x1 = x
x = x + dt * (3. * x)

FileHolder = open("ab.dat", "w+")
for i in range(2, m+1):
    time += dt
    tx = x
    x = x + dt * (1.5 * (3. * x) - 0.5 * (3. * x1))
    x1 = tx
    xa = 5.7 * math.exp(3. * time)
    FileHolder.writelines(str(time) + "\t" + str(x) + "\t" + str(xa) + "\n")
FileHolder.close()

discrepancy = x - xa
print(time, x, xa, discrepancy)
