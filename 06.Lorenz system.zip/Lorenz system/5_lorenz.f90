program lorenz
implicit none
integer, parameter :: m = 1000
integer :: i
double precision, parameter :: dt = 0.01
double precision :: sigma, beta, rho, time, discrepancy, sum, error
double precision :: x(m), y(m), z(m) 


x(1)=10.0
y(1)=10.0
z(1)=10.0

sigma=10.0
beta=8./3.
rho=28.0

time=0.0
open(unit=11, file='lorenz.dat')

do i = 2, m
   time=time+dt
   x(i)=x(i-1)+dt*sigma*(y(i-1)-x(i-1))
   y(i)=y(i-1)+dt*(x(i-1)*(rho-z(i-1))-y(i-1))
   z(i)=z(i-1)+dt*(x(i-1)*y(i-1)-beta*z(i-1))
   write(11,*)time, x(i), y(i), z(i)
end do


close(11)
end program lorenz