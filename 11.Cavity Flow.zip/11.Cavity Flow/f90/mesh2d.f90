MODULE VARIABLES
IMPLICIT NONE
INTEGER, PARAMETER :: N=40,M=40
DOUBLE PRECISION :: X(-1:N+1),Y(-1:M+1)
END MODULE VARIABLES


PROGRAM MESH 
USE VARIABLES
IMPLICIT NONE

DOUBLE PRECISION :: LENGTH,HEIGHT
DOUBLE PRECISION :: DXX, DYY
INTEGER :: I,J
         
      LENGTH=1.D0
      HEIGHT=1.D0
      DXX=LENGTH/(N*1.0)
      DYY=HEIGHT/(M*1.0)
      
!------------------------------------------------------------------------------------------------------------------------
	OPEN(UNIT=11,FILE='XX.DAT')

	DO I=1,N+1
		X(I)=DXX*(I-1)
		WRITE(11,*)X(I),I
	END DO           
    CLOSE(11)

     
	OPEN(UNIT=12,FILE='YY.DAT')

  
	DO J=1,M+1
		Y(J)=DYY*(J-1)
        WRITE(12,*)Y(J),J
    END DO
    CLOSE(12)


!--------------------------------------------------------------------------------------------------
 OPEN(UNIT=13,FILE='mesh.dat')
      WRITE(13,*)'VARIABLES=X,Y'
      WRITE(13,*)'ZONE I=',N,' ,J=',M
      DO  J=1,M+1
         DO  I=1,N+1
            WRITE(13,*)X(I),Y(J)
         END DO
      END DO
        WRITE(13,101)
        WRITE(13,*)0.5
101     FORMAT('GEOMETRY X= 6,Y= 5,T= CIRCLE, FC=BLUE, CS=GRID')
      CLOSE(13)
END PROGRAM MESH
