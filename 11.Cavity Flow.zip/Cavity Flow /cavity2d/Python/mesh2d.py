# Importing required libraries
import numpy as np

# Defining variables
length = 1.0
height = 1.0
n = 41
m = 41
dxx = length / (n * 1.0)
dyy = height / (m * 1.0)

# Creating XX.dat file
with open('XX.dat', 'w') as f:
    for i in range(-1, n+2):
        x_i = dxx * i
        f.write(f'{x_i} {i}\n')

# Creating YY.dat file
with open('YY.dat', 'w') as f:
    for j in range(-1, m+2):
        y_j = dyy * j
        f.write(f'{y_j} {j}\n')

# Creating mesh.dat file
with open('mesh.dat', 'w') as f:
    f.write('VARIABLES=X,Y\n')
    f.write(f'ZONE I={n}, J={m}\n')
    for j in range(1, m+1):
        for i in range(1, n+1):
            f.write(f'{dxx*i} {dyy*j}\n')