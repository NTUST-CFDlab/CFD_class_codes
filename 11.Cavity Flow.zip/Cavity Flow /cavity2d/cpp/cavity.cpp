/* ---------------------------------------------------------------
# Program Flow
#
#	THIS PROGRAM IS FOR SOLVING UNIFORM FLOW PAST A SQUARE CYLINDER
#	USING SOLA METHOD
#
#	AUTHOR: M. J. CHERN   DATE:4 JULY,2001
#
#
#       STAGGERED GRID (MAC)
#
#       NON-UNIFORM GRID VERSION
#         DATE: 14 MAY, 2002
#
#
#        QUICK SCHEME
#        DATE: 18 SEPT., 2002
#
#
#       PROGRAM MODIFIED FOR AN OSCIALLATING FLOW PAST A SQUARE CYLINDER
#       DATE: 26 OCt. 2002
#
#       MODIFY BOUNDARY CONDITIONS
#       DATE: 26 Nov. 2002
#
#       CONVERT TO FORTRAN 90 FORMAT
#       DATE: 20 SEPTEMBER 2011
#
#       NATURAL CONVECTION
#       DATE: 4 JAN. 2015
#
#       SOLA Method is replaced by projection method
#       This program is for cavity flow simualtions.
#       DATE: 14 May, 2015
#
#		Converted to C++ Code
#		DATE: 25 April 2023
# ---------------------------------------------------------------*/


#include<iostream>
#include<cstdlib>
#include<ctime>
#include<cmath>
#include<fstream>
#include<iomanip>
#include<sstream>
#include<cstring>
#include<chrono>

using namespace std;

int i, j;
const int N = 41;
const int M = 41;

double t1, t2;
double X[N + 2], Y[M + 2];
long double U[N + 2][M + 2], V[N + 2][M + 2];
long double UN1[N+1][M+1], VN1[N+1][M+1];
long double PRES[N + 2][M + 2];
long double ST[N+1][M+1], VORT[N+1][M+1];
long double FUU[N+1][M+1], FVV[N+1][M+1];
long double FUUN1[N+1][M+1], FVVN1[N+1][M+1];
long double FUUN2[N+1][M+1], FVVN2[N+1][M+1];
long double DP[N+1][M+1];
long double DX[N + 1], DX1[N + 1], DY[M + 1], DY1[M + 1];
long double TIME, PI, RE, DT, OMEGA;
int TTT, OT, FT, ITER, RERUN;



//-------------------------------------

void input() {
    ifstream infile;

    infile.open("XX.DAT");
    for (i = 0; i <= N + 2; i++) {
        infile >> X[i] >> i;
    }
    infile.close();

    infile.open("YY.DAT");
    for (j = 0; j <= M + 2; j++) {
        infile >> Y[j] >> i;
    }
    infile.close();

    for (i = 0; i <= N+1; i++) {
        DX[i] = X[i + 1] - X[i];
    }

    for (i = 0; i <= N; i++) {
        DX1[i] = 0.5 * (X[i + 2] - X[i]);
    }

    for (j = 0; j <= M+1; j++) {
        DY[j] = Y[j + 1] - Y[j];
    }
    for (j = 0; j <= M; j++) {
        DY1[j] = 0.5 * (Y[j + 2] - Y[j]);
    }
//
//	Inserting parameters from PARA.TXT
//

    infile.open("PARA.F");

    if (!infile.is_open()) {
        cerr << "Failed to open file: " << endl;
    }

    string line;
 
    if (getline(infile, line)) {
       istringstream iss(line);
        string token;

        if (getline(iss, token, ',')) {
            TTT = stoi(token);
        }

        if (getline(iss, token, ',')) {
            OT = stoi(token);
        }

        if (getline(iss, token, ',')) {
            DT = stod(token);
        }
		
		if (getline(iss, token, ',')) {
            FT = stoi(token);
        }
		
		if (getline(iss, token, ',')) {
            ITER = stoi(token);
        }
		
		if (getline(iss, token, ',')) {
            RE = stod(token);
        }
		
		if (getline(iss, token, ',')) {
            OMEGA = stod(token);
        }
		
		if (getline(iss, token, ',')) {
            RERUN = stoi(token);
        }
    }

    infile.close();


    TIME = 0.0;

    for (i = 0; i <= N + 2; i++) {
        for (j = 0; j <= M + 2; j++) {
            U[i][j] = 0.0;
            V[i][j] = 0.0;
            PRES[i][j] = 0.0;
        }
    }
}

//-------------------------------------

void boundary()
{
	// DEFINE U(1,Y),V(1,Y)
	
    for (int j = 1; j <= M+1; j++)
    {
        U[N][j] = 0.0;
        U[N+1][j] = 0.0;
        V[N+1][j] = -V[N][j];
        V[N + 2][j] = V[N + 1][j];
    }

	// DEFINE U(0,Y),V(0,Y)
	
    for (int j = 1; j <= M+1; j++)
    {
        U[1][j] = 0.0;
        V[1][j] = -V[2][j];
        U[0][j] = 0.0;
        V[0][j] = V[1][j];
    }

	// DEFINE U(X,0),V(X,0)
	
    for (int i = 2; i <= N+1; i++)
    {
        U[i][1] = -U[i][2];
        V[i][1] = 0.0;
        U[i][0] = U[i][1];
        V[i][0] = 0.0;
    }

	// DEFINE U(X,1),V(X,1)
	
    for (int i = 1; i <= N+1; i++)
    {
        U[i][M+1] = 2.0 - U[i][M];
        V[i][M] = 0.0;
        U[i][M + 2] = U[i][M + 1];
        V[i][M+1] = V[i][M];
    }
}

//-------------------------------------

void pressure_boundary() {
    for (int j=1; j<=M+1; j++) {
        PRES[1][j] = PRES[2][j];
        PRES[N+1][j] = PRES[N][j];
    }
    for (int i=2; i<=N+1; i++) {
        PRES[i][1] = PRES[i][2];
        PRES[i][M+1] = PRES[i][M];
    }
}

//-------------------------------------

void quick() {
	long double FUX, FUY, FUC, FVX, FVY, FVC;
	long double VISX, VISY, VDX, VDY;
	long double UE, UE1, UNN, UW, UW1, US1;
	long double VN, VE1, VNN, VS, VW1, VS1;
	long double X1, X2, X3, X4, X5, X6, X7, X8;
	long double Y1, Y2, Y3, Y4, Y5, Y6, Y7, Y8;
	long double A1, A2, A3;

    for (i = 2; i <= N - 1; i++) {
        for (j = 2; j <= M; j++) {
            X1 = DX[i] / 2. ;
			X2 = DX[i + 1] / 2. ;
			X3 = DX[i + 1] + DX[i + 2] / 2. ;
			X4 = DX[i - 1] + DX[i] / 2. ;
			X5 = DX[i] / 2. ;
			X6 = DX[i - 1] / 2. ;
			X7 = DX[i - 1] + DX[i - 2] / 2. ;
			X8 = DX[i] + DX[i + 1] / 2. ;
			
			UE = 0.5 * (DX[i] * U[i + 1][j] / DX1[i] + DX[i + 1] * U[i][j] / DX1[i]) ;
			
			if (UE > 0.) {
			    A1 = X2 * X4 / (X4 - X1) / (X1 + X2) ;
			    A2 = X1 * X4 / (X1 + X2) / (X2 + X4) ;
			    A3 = -X1 * X2 / (X4 - X1) / (X2 + X4) ;
			    UE1 = A1 * U[i][j] + A2 * U[i + 1][j] + A3 * U[i - 1][j] ;
			} else {
			    A1 = -X1 * X3 / (X1 + X2) / (X2 - X3) ;
			    A2 = X2 * X3 / (X1 + X3) / (X1 + X2) ;
			    A3 = X1 * X2 / (X1 + X3) / (X2 - X3) ;
			    UE1 = A1 * U[i + 1][j] + A2 * U[i][j] + A3 * U[i + 2][j] ;
			}

			UW = 0.5 * (DX[i] * U[i - 1][j] / DX1[i - 1] + DX[i - 1] * U[i][j] / DX1[i - 1]) ;

			if (UW > 0.0) {
				A1 = X5 * X7 / (X7 - X6) / (X5 + X6) ; 
				A2 = X6 * X7 / (X5 + X7) / (X5 + X6) ;
				A3 = -X5 * X6 / (X7 - X6) / (X5 + X7) ;
				UW1 = A1 * U[i - 1][j] + A2 * U[i][j] + A3 * U[i - 2][j] ;
			} else {
		    		A1 = X6 * X8 / (X5 + X6) / (X8 - X5);
		    		A2 = X5 * X8 / (X5 + X6) / (X6 + X8);
		    		A3 = -X5 * X6 / (X6 + X8) / (X8 - X5);
		    		UW1 = A1 * U[I][J] + A2 * U[I - 1][J] + A3 * U[I + 1][J];
			}

			FUX = (UE * UE1 - UW * UW1) / DX[i] ;
			
			Y1 = DY[j] / 2. ;
			Y2 = DY[j] / 2. ;
			Y3 = DY[j + 1] + DY[j] / 2. ;
			Y4 = DY[j - 1] + DY[j] / 2. ;
			Y5 = DY[j - 1] / 2. ;
			Y6 = DY[j - 1] / 2. ;
			Y7 = DY[j - 2] + DY[j - 1] / 2. ;
			Y8 = DY[j] + DY[j - 1] / 2. ;
			
			VN = 0.5 * (V[i][j] + V[i + 1][j]) ;
			
            if (VN > 0.) {
                A1 = Y2 * Y4 / (Y4 - Y1) / (Y1 + Y2) ;
				A2 = Y1 * Y4 / (Y1 + Y2) / (Y2 + Y4) ;
				A3 = -Y1 * Y2 / (Y4 - Y1) / (Y2 + Y4) ;
				UNN = A1 * U[i][j] + A2 * U[i][j + 1] + A3 * U[i][j - 1] ;
            } else {
                A1 = -Y1 * Y3 / (Y1 + Y2) / (Y2 - Y3) ;
				A2 = Y2 * Y3 / (Y1 + Y3) / (Y1 + Y2) ;
				A3 = Y1 * Y2 / (Y1 + Y3) / (Y2 - Y3) ;
				UNN = A1 * U[i][j + 1] + A2 * U[i][j] + A3 * U[i][j + 2] ;
            }
			
            VS = 0.5 * (V[i][j - 1] + V[i + 1][j - 1]) ;
			
            if (VS > 0.) {
                A1 = Y5 * Y7 / (Y7 - Y6) / (Y5 + Y6) ;
				A2 = Y6 * Y7 / (Y5 + Y7) / (Y5 + Y6) ;
				A3 = -Y5 * Y6 / (Y7 - Y6) / (Y5 + Y7) ;
				US1 = A1 * U[i][j - 1] + A2 * U[i][j] + A3 * U[i][j - 2] ;
            } else {
                A1 = Y6 * Y8 / (Y5 + Y6) / (Y8 - Y5) ;
				A2 = Y5 * Y8 / (Y5 + Y6) / (Y6 + Y8) ;
				A3 = -Y5 * Y6 / (Y6 + Y8) / (Y8 - Y5) ;
				US1 = A1 * U[i][j] + A2 * U[i][j - 1] + A3 * U[i][j + 1] ;
            }
            
			FUY = (VN * UNN - VS * US1) / DY1[j - 1] ;
			
			FUC = 0. ;
			VDX = (U[i + 1][j] - U[i][j]) / DX[i] - (U[i][j] - U[i - 1][j]) / DX[i - 1] ;
			VDX = VDX / DX1[i - 1] ;
			VDY = (U[i][j + 1] - U[i][j]) / DY1[j] - (U[i][j] - U[i][j - 1]) / DY1[j - 1] ;
			VDY = VDY / DY[j] ;
			VISX = (VDX + VDY) / RE ;
			FUU[i][j] = DT * (-FUX - FUY - FUC + VISX) ;
		}
	}
	
    for (i = 2; i <= N; i++) {
        for (j = 2; j <= M-1; j++) {
	        X1 = DX[i] / 2. ;
	        X2 = DX[i] / 2. ;
	        X3 = DX[i + 1] + DX[i] / 2. ;
	        X4 = DX[i - 1] + DX[i] / 2. ;
	        X5 = DX[i - 1] / 2. ;
	        X6 = DX[i - 1] / 2. ;
	        X7 = DX[i - 2] + DX[i - 1] / 2. ;
	        X8 = DX[i] + DX[i - 1] / 2. ;
	
	        UE = 0.5 * (U[i][j] + U[i][j + 1]) ;
			
	        if (UE > 0.) {
	            A1 = X2 * X4 / (X4 - X1) / (X1 + X2) ;
	            A2 = X1 * X4 / (X1 + X2) / (X2 + X4) ;
	            A3 = -X1 * X2 / (X4 - X1) / (X2 + X4) ;
	            VE1 = A1 * V[i][j] + A2 * V[i + 1][j] + A3 * V[i - 1][j] ;
	        } else {
	            A1 = -X1 * X3 / (X1 + X2) / (X2 - X3) ;
	            A2 = X2 * X3 / (X1 + X3) / (X1 + X2) ;
	            A3 = X1 * X2 / (X1 + X3) / (X2 - X3) ;
	            VE1 = A1 * V[i + 1][j] + A2 * V[i][j] + A3 * V[i + 2][j] ;
			}
			
	        UW = 0.5 * (U[i - 1][j] + U[i - 1][j + 1]) ;
	        
			if (UW > 0.) {
	            A1 = X5 * X7 / (X7 - X6) / (X5 + X6) ;
	            A2 = X6 * X7 / (X5 + X7) / (X5 + X6) ;
	            A3 = -X5 * X6 / (X7 - X6) / (X5 + X7) ;
	            VW1 = A1 * V[i - 1][j] + A2 * V[i][j] + A3 * V[i - 2][j] ;
	        } else {
	            A1 = X6 * X8 / (X5 + X6) / (X8 - X5) ;
	            A2 = X5 * X8 / (X5 + X6) / (X6 + X8) ;
	            A3 = -X5 * X6 / (X6 + X8) / (X8 - X5) ;
	            VW1 = A1 * V[i][j] + A2 * V[i - 1][j] + A3 * V[i + 1][j] ;
			}
			
	        FVX = (UE * VE1 - UW * VW1) / DX1[i - 1] ;
	        
			Y1 = DY[j] / 2.  ;
	        Y2 = DY[j + 1] / 2. ;
	        Y3 = DY[j + 1] + DY[j + 2] / 2. ;
	        Y4 = DY[j - 1] + DY[j] / 2. ;
	        Y5 = DY[j] / 2. ;
	        Y6 = DY[j - 1] / 2. ;
	        Y7 = DY[j - 1] + DY[j - 2] / 2. ;
	        Y8 = DY[j] + DY[j + 1] / 2. ;
	
	        VN = 0.5 * (DY[j + 1] * V[i][j] / DY1[j] + DY[j] * V[i][j + 1] / DY1[j]) ;
	        
			if (VN > 0.) {
	            A1 = Y2 * Y4 / (Y4 - Y1) / (Y1 + Y2) ;
	            A2 = Y1 * Y4 / (Y1 + Y2) / (Y2 + Y4) ;
	            A3 = -Y1 * Y2 / (Y4 - Y1) / (Y2 + Y4) ;
	            VNN = A1 * V[i][j] + A2 * V[i][j + 1] + A3 * V[i][j - 1] ;
	        } else {
	            A1 = -Y1 * Y3 / (Y1 + Y2) / (Y2 - Y3) ;
	            A2 = Y2 * Y3 / (Y1 + Y3) / (Y1 + Y2) ;
	            A3 = Y1 * Y2 / (Y1 + Y3) / (Y2 - Y3) ;
	            VNN = A1 * V[i][j + 1] + A2 * V[i][j] + A3 * V[i][j + 2] ;
			}
			
	        VS = 0.5 * (DY[j] * V[i][j - 1] / DY1[j - 1] + DY[j - 1] * V[i][j] / DY1[j - 1]) ;
	        
			if (VS > 0.) {
	            A1 = Y5 * Y7 / (Y7 - Y6) / (Y5 + Y6) ;
	            A2 = Y6 * Y7 / (Y5 + Y7) / (Y5 + Y6) ;
	            A3 = -Y5 * Y6 / (Y7 - Y6) / (Y5 + Y7) ;
	            VS1 = A1 * V[i][j - 1] + A2 * V[i][j] + A3 * V[i][j - 2] ;
	        } else {
	            A1 = Y6 * Y8 / (Y5 + Y6) / (Y8 - Y5) ;
	            A2 = Y5 * Y8 / (Y5 + Y6) / (Y6 + Y8) ;
	            A3 = -Y5 * Y6 / (Y6 + Y8) / (Y8 - Y5) ;
	            VS1 = A1 * V[i][j] + A2 * V[i][j - 1] + A3 * V[i][j + 1] ;
			}
			
	        FVY = (VN * VNN - VS * VS1) / DY[j] ;
	        
			FVC = 0. ;
	        VDX = (V[i + 1][j] - V[i][j]) / DX[i] - (V[i][j] - V[i - 1][j]) / DX[i - 1] ;
	        VDX = VDX / DX1[i - 1] ;
	        VDY = (V[i][j + 1] - V[i][j]) / DY1[j] - (V[i][j] - V[i][j - 1]) / DY1[j - 1] ;
	        VDY = VDY / DY[j] ;
	        VISY = (VDX + VDY) / RE ;
	        FVV[i][j] = DT * (-FVX - FVY - FVC + VISY) ;
		}
	}
}

//-------------------------------------

void solver() {
	long double DD;
	long double TEMP, DMAX;
	long double UTEMP, VTEMP;
	long double TS, TOL;
	long double AP, AN, AS, AW, AE;
	int TITE, PPPP, REIT, II, JJ;
	char REFILE[12], LASTFILE[12];

    TIME=0. ;     
	REIT=1  ;
    
    for (i = 1; i <= N+1; i++) {
        for (j = 1; j <= M+1; j++) {
            UN1[i][j] = U[i][j];
            VN1[i][j] = V[i][j];
            FUUN1[i][j] = 0.0;
            FUUN2[i][j] = 0.0;
            FVVN1[i][j] = 0.0;
            FVVN2[i][j] = 0.0;
        }
    }
	
    if (RERUN == 1) {
        strcpy(LASTFILE, "LAST.DAT");
        ifstream infile(LASTFILE);
        infile >> TIME;
        infile >> REIT;
        for (i = 1; i <= N+1; i++) {
            for (j = 1; j <= M+1; j++) {
                infile >> U[i][j] >> V[i][j] >> PRES[i][j];
            }
        }
        for (j = 1; j <= M+1; j++) {
            for (i = 1; i <= N+1; i++) {
                infile >> FUUN1[i][j] >> FUUN2[i][j] >> FVVN1[i][j] >> FVVN2[i][j];
            }
        }
        infile.close();
        REIT++;
    }
    TOL = 1.0e-4;
    ofstream flow("flow.dat");
    
    // Time stepping loop
    for (TITE = REIT; TITE <= TTT; TITE++) {
        TIME += DT;
        cout << "TIME = " << TIME << endl;
        
//       PREDICTION
//       SOLVING VELOCITY FIELD
//       USING QUICK SCHEME


    quick();
  


	for(i=2; i<= N-1; i++){
		for(j=2; j<= M; j++){
			if(REIT == 1){
				U[i][j] = U[i][j] + FUU[i][j];
			}
			else{
				if(REIT == 2){
					U[i][j] = U[i][j] + 1.5*FUU[i][j] - 0.5*FUUN1[i][j];
				}
				else{
					U[i][j] = U[i][j] + (23.*FUU[i][j] - 16.*FUUN1[i][j] + 5.*FUUN2[i][j])/12.;
				}
			}
        FUUN2[i][j] = FUUN1[i][j];
        FUUN1[i][j] = FUU[i][j];
		}
	}

	for(i=2; i<= N; i++){
		for(j=2; j<= M-1; j++){
			if(REIT == 1){
				V[i][j] = V[i][j] + FVV[i][j];
			}
			else{
				if(REIT == 2){
					V[i][j] = V[i][j] + 1.5*FVV[i][j] - 0.5*FVVN1[i][j];
				}
				else{
					V[i][j] = V[i][j] + (23.*FVV[i][j] - 16.*FVVN1[i][j] + 5.*FVVN2[i][j])/12.;
				}
			}
        FVVN2[i][j] = FVVN1[i][j];
        FVVN1[i][j] = FVV[i][j];
		}
	}
	
	boundary();

	
//
//     U,V,W AND P ---- PROJECTION METHOD
//
	
	for (PPPP = 1; PPPP <= ITER; PPPP++) {		
//
//    PRESSURE CORRECTION 
//
		DMAX = 0.0;

		for (i = 2; i <= N; i++) {
			for (j = 2; j <= M; j++) {
				DD = (U[i][j] - U[i-1][j]) * DY[j] + (V[i][j] - V[i][j-1]) * DX[i];
				AP = -DY[j] / DX1[i] - DY[j] / DX1[i-1] - DX[i] / DY1[j] - DX[i] / DY1[j-1];
				AE = DY[j] / DX1[i];
				AW = DY[j] / DX1[i-1];
				AN = DX[i] / DY1[j];
				AS = DX[i] / DY1[j-1];
				DP[i][j] = -AP * PRES[i][j] - AE * PRES[i+1][j] - AW * PRES[i-1][j] - AN * PRES[i][j+1] - AS * PRES[i][j-1] + DD / DT;
				DP[i][j] /= AP;
				PRES[i][j] += OMEGA * DP[i][j];
				if (abs(DP[i][j]) > DMAX) {
					DMAX = fabs(DP[i][j]);
					II = i;
					JJ = j;
				}
			}
		}
    pressure_boundary();
	
								
				

    if (DMAX < TOL) goto label89;
	}

	label89:
	for (i = 2; i <= N-1; i++) {
		for (j = 2; j <= M; j++) {
			U[i][j] -= DT * (PRES[i+1][j] - PRES[i][j]) / DX1[i];
		}
	}

	for (i = 2; i <= N; i++) {
		for (j = 2; j <= M-1; j++) {
			V[i][j] -= DT * (PRES[i][j+1] - PRES[i][j]) / DY1[j];
		}
	}



	boundary();

	
//-------------------------------------

	TEMP = 0.0;
	TS = 0.0;

	for (i = 1; i <= N+1; i++) {
		for (j = 1; j <= M+1; j++) {
			UTEMP = abs(U[i][j] - UN1[i][j]);
			VTEMP = abs(V[i][j] - VN1[i][j]);
			TS += UTEMP * UTEMP + VTEMP * VTEMP;

			if (UTEMP > VTEMP) {
				if (UTEMP > TEMP)
					TEMP = UTEMP;
				}
				else if (VTEMP > TEMP) {
				TEMP = VTEMP;
				}

			UN1[i][j] = U[i][j];
			VN1[i][j] = V[i][j];
		}
	}

	TS = sqrt(TS / 2.0 / (N + 1) / (M + 1));

	cout << "UV-P ITERATION NUMBER = " << PPPP << endl;
	cout << "DMAX = " << DMAX << " ,I = " << II << " ,J = " << JJ << endl;
	cout << "THE MAX. VARIATION = " << TEMP << " ,SQRT OF VARIATION = " << TS << endl;

	if (TITE % FT == 0) {
		flow << TITE << " " << TIME << " " << PPPP << " " << TEMP << " " << TS << endl;
	}

//
//     OUTPUT NUMERICAL RESULTS
//
	
	if (TITE % OT == 0) {
		ostringstream filename_stream;
		filename_stream << setfill('0');
		filename_stream << setw(5) << TITE / OT;
		string filename = "CA" + filename_stream.str()+".DAT";
			if (TITE / OT < 10) filename.replace(2, 4, "0000");
			if (TITE / OT < 100) filename.replace(2, 3, "000");
			if (TITE / OT < 1000) filename.replace(2, 2, "00");
			if (TITE / OT < 10000) filename.replace(2, 1, "0");
		ofstream file(filename.c_str());
		for ( i = 1; i <= N+1; i++) {
			for (j = 1; j <= M+1; j++) {
				ST[i][j] = 0.0;
				VORT[i][j] = 0.0;
			}
		}
		for (i = 2; i <= N ; i++) {
			ST[i][1] = 0.0;
			VORT[i][j] = 0.0;
			for (j = 2; j <= M ; j++) {
				ST[i][j] = ST[i][j - 1] + (Y[j + 1] - Y[j]) * U[i][j];
				VORT[i][j] = -(U[i - 1][j] - U[i - 1][j - 1]) / (0.5 * (Y[j + 1] - Y[j - 1])) +
                         (V[i][j - 1] - V[i - 1][j - 1]) / (0.5 * (X[i + 1] - X[i - 1]));
			}
		}
		file << "TITLE=\"CAVITY FLOW\"\n";
		file << "VARIABLES=X,Y,U,V,P,STREAM,VORTICITY\n";
		file << "ZONE T=\"CAVITY FLOW\", I=" << N << ", J=" << M << ", F=POINT\n";
		for (j = 1; j <= M; j++) {
			for (i = 1; i <= N; i++) {
				file << fixed << setprecision(7) << (X[i] + X[i + 1]) / 2.0 << " " << (Y[j] + Y[j + 1]) / 2.0 << " "
                     << U[i][j] << " " << V[i][j] << " " << PRES[i][j] << " " << ST[i][j] << " " << VORT[i][j] << "\n";
			}
		}


		ofstream REFILE("REFILE");
		REFILE << TIME << '\n';
		REFILE << TITE << '\n';
		for (j = 1; j <= M+1; j++) {
			for (i = 1; i <= N+1; i++) {
				REFILE << U[i][j] << ' ' << V[i][j] << ' ' << PRES[i][j] << '\n';
			}
		}
		for (j = 1; j <= M+1; j++) {
			for (i = 1; i <= N+1; i++) {
				REFILE << FUUN1[i][j] << ' ' << FUUN2[i][j] << ' ' << FVVN1[i][j] << ' ' << FVVN2[i][j] << '\n';
			}
		}
		REFILE.close();
		file.close();
	}
	}
	flow.close();
}

//-------------------------------------

int main() {
    ifstream in_file("CLOCK.DAT");
    ofstream out_file("CLOCK.OUT");
  
    clock_t t1 = clock();

    input();
    cout << "INPUT PASS" << endl;
	
    solver();
  
    clock_t t2 = clock();
    double elapsed_secs = double(t2 - t1) / CLOCKS_PER_SEC;
    out_file << "Time taken by code was " << elapsed_secs << " seconds" << endl;
    cout << "SOLVER PASS" << endl;

    return 0;
}
