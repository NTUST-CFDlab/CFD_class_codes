# Importing required libraries
import numpy as np
from time import time

# Defining variables
x_Bound = [0., 20.]   # xmin, xmax
y_Bound = [0., 10.]    # ymin, ymax
N, M = 201, 101        # mesh in x, mesh in y

# Make sure the PARA.F is uploaded to the colab

# DFIB
Cylinder_Center = [6., 5.]  # x, y
Cylinder_Radius = 0.5
uSolid = [0., 0.]   # u, v

##################################################################
# Mesh Code
##################################################################
length = x_Bound[1] - x_Bound[0]
height = y_Bound[1] - y_Bound[0]

dxx = length / N
dyy = height / M

# Creating XX.dat file
with open('XX.DAT', 'w') as f:
    for i in range(-1, N+2):
        x_i = dxx * i + x_Bound[0]
        f.write(f'{x_i} {i}\n')

# Creating YY.dat file
with open('YY.DAT', 'w') as f:
    for j in range(-1, M+2):
        y_j = dyy * j + y_Bound[0]
        f.write(f'{y_j} {j}\n')

# Creating mesh.dat file
with open('mesh.dat', 'w') as f:
    f.write('VARIABLES=X,Y\n')
    f.write(f'ZONE I={N}, J={M}\n')
    for j in range(1, M+1):
        for i in range(1, N+1):
            f.write(f'{dxx*i + x_Bound[0]} {dyy*j + y_Bound[0]}\n')
