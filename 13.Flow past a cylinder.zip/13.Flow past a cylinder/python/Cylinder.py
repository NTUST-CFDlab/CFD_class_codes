# ---------------------------------------------------------------
# Program Flow
#
#	THIS PROGRAM IS FOR SOLVING UNIFORM FLOW PAST A SQUARE CYLINDER
#	USING SOLA METHOD
#
#	AUTHOR: M. J. CHERN   DATE:4 JULY,2001
#
#
#       STAGGERED GRID (MAC)
#
#       NON-UNIFORM GRID VERSION
#         DATE: 14 MAY, 2002
#
#
#        QUICK SCHEME
#        DATE: 18 SEPT., 2002
#
#
#       PROGRAM MODIFIED FOR AN OSCIALLATING FLOW PAST A SQUARE CYLINDER
#       DATE: 26 OCt. 2002
#
#       MODIFY BOUNDARY CONDITIONS
#       DATE: 26 Nov. 2002
#
#       CONVERT TO FORTRAN 90 FORMAT
#       DATE: 20 SEPTEMBER 2011
#
#       NATURAL CONVECTION
#       DATE: 4 JAN. 2015
#
#       SOLA Method is replaced by projection method
#       This program is for cavity flow simualtions.
#       DATE: 14 May, 2015
#
#		Converted to Python Code
#		DATE: ????????????????????????????????
# ---------------------------------------------------------------

# Import
import numpy as np
from time import time

# Main Parameters
N = 41
M = 41

# Class (with function = Load_Input, Load_Velocity_Boudnary, Load_Pressure Boundary, QUICK, Solver)
class Main_Class():
    def __init__(self, N, M):
        # self.N = N	# M & N are always tranffered
        # self.M = M
        # Conversion:
        #	-1 to N+1	--> nx = N+3, ny = M+3
        #	-1 to N 	--> nx = N+2
        #	0  to N		--> nx = N+1
        # Example N = 2 --> n(-1 to 3) = 5

        # File Names
        self.x_Mesh_File = "XX.DAT"
        self.y_Mesh_File = "YY.DAT"
        self.Parameter_File = "PARA.F"

        # Main Variables
        self.U = np.zeros((M + 3, N + 3))
        self.V = np.zeros((M + 3, N + 3))
        self.P = np.zeros((M + 3, N + 3))

        # Derivatives Vars
        self.DX = np.zeros(N + 2)
        self.DX1 = np.zeros(N + 2)
        self.DY = np.zeros(M + 2)
        self.DY1 = np.zeros(M + 2)

    def Load_Input(self):
        self.X = np.float64(np.loadtxt(self.x_Mesh_File, usecols=(0)))
        self.Y = np.float64(np.loadtxt(self.y_Mesh_File, usecols=(0)))
        nx = len(self.X)
        ny = len(self.Y)

        for i in range(nx - 1):
            self.DX[i] = self.X[i + 1] - self.X[i]
        for i in range(nx - 2):
            self.DX1[i] = 0.5 * (self.X[i + 2] - self.X[i])

        for j in range(ny - 1):
            self.DY[j] = self.Y[j + 1] - self.Y[j]
        for j in range(ny - 2):
            self.DY1[j] = 0.5 * (self.Y[j + 2] - self.Y[j])

        Temp_Text = np.loadtxt(self.Parameter_File, delimiter=',')
        [self.TTT, OT, self.DT, FT, self.ITER, self.RE, self.OMEGA, self.RERUN] = np.float64(Temp_Text[0])

        self.Time = 0.
        for i in range(nx):
            for j in range(ny):
                self.U[i][j] = 0.
                self.V[i][j] = 0.
                self.P[i][j] = 0.

    def Load_Vel_Boundary(self, N, M):
        for j in range(1, M + 2):
            self.U[N][j] = 0.
            self.U[N + 1][j] = 0.
            self.V[N + 1][j] = self.V[N][j]
            self.V[N + 2][j] = self.V[N + 1][j]

        for j in range(1, M + 2):
            self.U[1][j] = 0.
            self.V[1][j] = self.V[2][j]
            self.U[0][j] = 0.
            self.V[0][j] = self.V[1][j]

        for i in range(2, N + 2):
            self.U[i][1] = self.U[i][2]
            self.V[i][1] = 0.
            self.U[i][0] = self.U[i][1]
            self.V[i][0] = 0.

        for i in range(1, N + 2):
            self.U[i][M + 1] = 2. - self.U[i][M]
            self.V[i][M] = 0.
            self.U[i][M + 2] = self.U[i][M + 1]
            self.V[i][M + 1] = self.V[i][M]

    def Load_Pressure_Boundary(self, N, M):
        for j in range(1, M + 2):
            self.P[1][j] = self.P[2][j]
            self.P[N + 1][j] = self.P[N][j]

        for i in range(2, N + 2):
            self.P[i][1] = self.P[i][2]
            self.P[i][M + 1] = self.P[i][M]

    def QUICK(self, N, M):
        FUU = np.zeros((M + 3, N + 3))
        FVV = np.zeros((M + 3, N + 3))

        for i in range(2, N):
            for j in range(2, M + 1):
                X1 = self.DX[i] / 2.
                X2 = self.DX[i + 1] / 2.
                X3 = self.DX[i + 1] + self.DX[i + 2] / 2.
                X4 = self.DX[i - 1] + self.DX[i] / 2.
                X5 = self.DX[i] / 2.
                X6 = self.DX[i - 1] / 2.
                X7 = self.DX[i - 1] + self.DX[i - 2] / 2.
                X8 = self.DX[i] + self.DX[i + 1] / 2.

                UE = 0.5 * (self.DX[i] * self.U[i + 1][j] / self.DX1[i] + self.DX[i + 1] * self.U[i][j] / self.DX1[i])
                if UE > 0.:
                    A1 = X2 * X4 / (X4 - X1) / (X1 + X2)
                    A2 = X1 * X4 / (X1 + X2) / (X2 + X4)
                    A3 = -X1 * X2 / (X4 - X1) / (X2 + X4)
                    UE1 = A1 * self.U[i][j] + A2 * self.U[i + 1][j] + A3 * self.U[i - 1][j]
                else:
                    A1 = -X1 * X3 / (X1 + X2) / (X2 - X3)
                    A2 = X2 * X3 / (X1 + X3) / (X1 + X2)
                    A3 = X1 * X2 / (X1 + X3) / (X2 - X3)
                    UE1 = A1 * self.U[i + 1][j] + A2 * self.U[i][j] + A3 * self.U[i + 2][j]

                # A1=X6*X8/(X5+X6)/(X8-X5)
                # A2=X5*X8/(X5+X6)/(X6+X8)
                # A3=-X5*X6/(X6+X8)/(X8-X5)

                UW = 0.5 * (self.DX[i] * self.U[i - 1][j] / self.DX1[i - 1] + self.DX[i - 1] * self.U[i][j] / self.DX1[i - 1])
                if UW > 0.:
                    A1 = X5 * X7 / (X7 - X6) / (X5 + X6)
                    A2 = X6 * X7 / (X5 + X7) / (X5 + X6)
                    A3 = -X5 * X6 / (X7 - X6) / (X5 + X7)
                    UW1 = A1 * self.U[i - 1][j] + A2 * self.U[i][j] + A3 * self.U[i - 2][j]
                else:
                    A1 = X6 * X8 / (X5 + X6) / (X8 - X5)
                    A2 = X5 * X8 / (X5 + X6) / (X6 + X8)
                    A3 = -X5 * X6 / (X6 + X8) / (X8 - X5)
                    UW1 = A1 * self.U[i][j] + A2 * self.U[i - 1][j] + A3 * self.U[i + 1][j]

                FUX = (UE * UE1 - UW * UW1) / self.DX[i]

                Y1 = self.DY[j] / 2.
                Y2 = self.DY[j] / 2.
                Y3 = self.DY[j + 1] + self.DY[j] / 2.
                Y4 = self.DY[j - 1] + self.DY[j] / 2.
                Y5 = self.DY[j - 1] / 2.
                Y6 = self.DY[j - 1] / 2.
                Y7 = self.DY[j - 2] + self.DY[j - 1] / 2.
                Y8 = self.DY[j] + self.DY[j - 1] / 2.

                VN = 0.5 * (self.V[i][j] + self.V[i + 1][j])
                if VN > 0.:
                    A1 = Y2 * Y4 / (Y4 - Y1) / (Y1 + Y2)
                    A2 = Y1 * Y4 / (Y1 + Y2) / (Y2 + Y4)
                    A3 = -Y1 * Y2 / (Y4 - Y1) / (Y2 + Y4)
                    UNN = A1 * self.U[i][j] + A2 * self.U[i][j + 1] + A3 * self.U[i][j - 1]
                else:
                    A1 = -Y1 * Y3 / (Y1 + Y2) / (Y2 - Y3)
                    A2 = Y2 * Y3 / (Y1 + Y3) / (Y1 + Y2)
                    A3 = Y1 * Y2 / (Y1 + Y3) / (Y2 - Y3)
                    UNN = A1 * self.U[i][j + 1] + A2 * self.U[i][j] + A3 * self.U[i][j + 2]

                VS = 0.5 * (self.V[i][j - 1] + self.V[i + 1][j - 1])
                if VS > 0.:
                    A1 = Y5 * Y7 / (Y7 - Y6) / (Y5 + Y6)
                    A2 = Y6 * Y7 / (Y5 + Y7) / (Y5 + Y6)
                    A3 = -Y5 * Y6 / (Y7 - Y6) / (Y5 + Y7)
                    US1 = A1 * self.U[i][j - 1] + A2 * self.U[i][j] + A3 * self.U[i][j - 2]
                else:
                    A1 = Y6 * Y8 / (Y5 + Y6) / (Y8 - Y5)
                    A2 = Y5 * Y8 / (Y5 + Y6) / (Y6 + Y8)
                    A3 = -Y5 * Y6 / (Y6 + Y8) / (Y8 - Y5)
                    US1 = A1 * self.U[i][j] + A2 * self.U[i][j - 1] + A3 * self.U[i][j + 1]

                FUY = (VN * UNN - VS * US1) / self.DY1[j - 1]

                FUC = 0.
                VDX = (self.U[i + 1][j] - self.U[i][j]) / self.DX[i] - (self.U[i][j] - self.U[i - 1][j]) / self.DX[i - 1]
                VDX = VDX / self.DX1[i - 1]
                VDY = (self.U[i][j + 1] - self.U[i][j]) / self.DY1[j] - (self.U[i][j] - self.U[i][j - 1]) / self.DY1[j - 1]
                VDY = VDY / self.DY[j]
                VISX = (VDX + VDY) / self.RE
                FUU[i][j] = self.DT * (-FUX - FUY - FUC + VISX)

        for i in range(2, N + 1):
            for j in range(2, M):
                X1 = self.DX[i] / 2.
                X2 = self.DX[i] / 2.
                X3 = self.DX[i + 1] + self.DX[i] / 2.
                X4 = self.DX[i - 1] + self.DX[i] / 2.
                X5 = self.DX[i - 1] / 2.
                X6 = self.DX[i - 1] / 2.
                X7 = self.DX[i - 2] + self.DX[i - 1] / 2.
                X8 = self.DX[i] + self.DX[i - 1] / 2.

                UE = 0.5 * (self.U[i][j] + self.U[i][j + 1])
                if UE > 0.:
                    A1 = X2 * X4 / (X4 - X1) / (X1 + X2)
                    A2 = X1 * X4 / (X1 + X2) / (X2 + X4)
                    A3 = -X1 * X2 / (X4 - X1) / (X2 + X4)
                    VE1 = A1 * self.V[i][j] + A2 * self.V[i + 1][j] + A3 * self.V[i - 1][j]
                else:
                    A1 = -X1 * X3 / (X1 + X2) / (X2 - X3)
                    A2 = X2 * X3 / (X1 + X3) / (X1 + X2)
                    A3 = X1 * X2 / (X1 + X3) / (X2 - X3)
                    VE1 = A1 * self.V[i + 1][j] + A2 * self.V[i][j] + A3 * self.V[i + 2][j]

                UW = 0.5 * (self.U[i - 1][j] + self.U[i - 1][j + 1])
                if UW > 0.:
                    A1 = X5 * X7 / (X7 - X6) / (X5 + X6)
                    A2 = X6 * X7 / (X5 + X7) / (X5 + X6)
                    A3 = -X5 * X6 / (X7 - X6) / (X5 + X7)
                    VW1 = A1 * self.V[i - 1][j] + A2 * self.V[i][j] + A3 * self.V[i - 2][j]
                else:
                    A1 = X6 * X8 / (X5 + X6) / (X8 - X5)
                    A2 = X5 * X8 / (X5 + X6) / (X6 + X8)
                    A3 = -X5 * X6 / (X6 + X8) / (X8 - X5)
                    VW1 = A1 * self.V[i][j] + A2 * self.V[i - 1][j] + A3 * self.V[i + 1][j]

                FVX = (UE * VE1 - UW * VW1) / self.DX1[i - 1]
                Y1 = self.DY[j] / 2.
                Y2 = self.DY[j + 1] / 2.
                Y3 = self.DY[j + 1] + self.DY[j + 2] / 2.
                Y4 = self.DY[j - 1] + self.DY[j] / 2.
                Y5 = self.DY[j] / 2.
                Y6 = self.DY[j - 1] / 2.
                Y7 = self.DY[j - 1] + self.DY[j - 2] / 2.
                Y8 = self.DY[j] + self.DY[j + 1] / 2.

                VN = 0.5 * (self.DY[j + 1] * self.V[i][j] / self.DY1[j] + self.DY[j] * self.V[i][j + 1] / self.DY1[j])
                if VN > 0.:
                    A1 = Y2 * Y4 / (Y4 - Y1) / (Y1 + Y2)
                    A2 = Y1 * Y4 / (Y1 + Y2) / (Y2 + Y4)
                    A3 = -Y1 * Y2 / (Y4 - Y1) / (Y2 + Y4)
                    VNN = A1 * self.V[i][j] + A2 * self.V[i][j + 1] + A3 * self.V[i][j - 1]
                else:
                    A1 = -Y1 * Y3 / (Y1 + Y2) / (Y2 - Y3)
                    A2 = Y2 * Y3 / (Y1 + Y3) / (Y1 + Y2)
                    A3 = Y1 * Y2 / (Y1 + Y3) / (Y2 - Y3)
                    VNN = A1 * self.V[i][j + 1] + A2 * self.V[i][j] + A3 * self.V[i][j + 2]

                VS = 0.5 * (self.DY[j] * self.V[i][j - 1] / self.DY1[j - 1] + self.DY[j - 1] * self.V[i][j] / self.DY1[j - 1])
                if VS > 0.:
                    A1 = Y5 * Y7 / (Y7 - Y6) / (Y5 + Y6)
                    A2 = Y6 * Y7 / (Y5 + Y7) / (Y5 + Y6)
                    A3 = -Y5 * Y6 / (Y7 - Y6) / (Y5 + Y7)
                    VS1 = A1 * self.V[i][j - 1] + A2 * self.V[i][j] + A3 * self.V[i][j - 2]
                else:
                    A1 = Y6 * Y8 / (Y5 + Y6) / (Y8 - Y5)
                    A2 = Y5 * Y8 / (Y5 + Y6) / (Y6 + Y8)
                    A3 = -Y5 * Y6 / (Y6 + Y8) / (Y8 - Y5)
                    VS1 = A1 * self.V[i][j] + A2 * self.V[i][j - 1] + A3 * self.V[i][j + 1]

                FVY = (VN * VNN - VS * VS1) / self.DY[j]
                FVC = 0.
                VDX = (self.V[i + 1][j] - self.V[i][j]) / self.DX[i] - (self.V[i][j] - self.V[i - 1][j]) / self.DX[i - 1]
                VDX = VDX / self.DX1[i - 1]
                VDY = (self.V[i][j + 1] - self.V[i][j]) / self.DY1[j] - (self.V[i][j] - self.V[i][j - 1]) / self.DY1[j - 1]
                VDY = VDY / self.DY[j]
                VISY = (VDX + VDY) / self.RE
                FVV[i][j] = self.DT * (-FVX - FVY - FVC + VISY)

        return FUU, FVV

    def Solver(self, N, M):
        FILENAME = 'CA00000.DAT'
        TIME = 0.
        REIT = 1

        UN1 = np.copy(self.U)
        VN1 = np.copy(self.V)
        FUUN1 = np.zeros((M + 3, N + 3))
        FUUN2 = np.zeros((M + 3, N + 3))
        FVVN1 = np.zeros((M + 3, N + 3))
        FVVN2 = np.zeros((M + 3, N + 3))
        DP = np.zeros((M + 3, N + 3))

        # NOT DONE
        if self.RERUN == 1:
            LASTFILE = 'LAST.DAT'
            #np.float64(np.loadtxt('LAST.DAT', usecols=(0)))
            # READ
            REIT += 1
        TOL = 1e-4
        # OPEN(UNIT=26,FILE='flow.dat')

        for TITE in range(REIT, self.TTT + 1):
            TIME += self.DT
            print("Time = " + str(TIME))

            FUU, FVV = self.QUICK(N, M)

            for i in range(2, N):
                for j in range(2, M + 1):
                    if REIT == 1:
                        self.U[i][j] += FUU[i][j]  # FUU assumed to have the same index format as U
                    elif REIT == 2:
                        self.U[i][j] += 1.5 * FUU[i][j] - 0.5 * FUUN1[i][j]
                    else:
                        self.U[i][j] += (23. * FUU[i][j] - 16. * FUUN1[i][j] + 5. * FUUN2[i][j]) / 12.
                    FUUN2[i][j] = FUUN1[i][j]
                    FUUN1[i][j] = FUU[i][j]

            for i in range(2, N + 1):
                for j in range(2, M):
                    if REIT == 1:
                        self.V[i][j] += FVV[i][j]
                    elif REIT == 2:
                        self.V[i][j] += 1.5 * FVV[i][j] - 0.5 * FVVN1[i][j]
                    else:
                        self.V[i][j] += (23. * FVV[i][j] - 16. * FVVN1[i][j] + 5. * FVVN2[i][j]) / 12.
                    FVVN2[i][j] = FVVN1[i][j]
                    FVVN1[i][j] = FVV[i][j]

            self.Load_Vel_Boundary(N, M)

            for PPPP in range(1, self.ITER + 1):
                DMAX = 0.
                for i in range(2, N + 1):
                    for j in range(2, M + 1):
                        DD = (self.U[i][j] - self.U[i - 1][j]) * self.DY[j] + (self.V[i][j] - self.V[i][j - 1]) * \
                             self.DX[i]

                        AP = -self.DY[j] / self.DX1[i] - self.DY[j] / self.DX1[i - 1] - self.DX[i] / self.DY1[j] - \
                             self.DX[i] / self.DY1[j - 1]
                        AE = self.DY[j] / self.DX1[i]
                        AW = self.DY[j] / self.DX1[i - 1]
                        AN = self.DX[i] / self.DY1[j]
                        AS = self.DX[i] / self.DY[j - 1]

                        DP[i][j] = -AP * self.P[i][j] - AE * self.P[i + 1][j] - AW * self.P[i - 1][j] - AN * self.P[i][
                            j + 1] - AS * self.P[i][j - 1] + DD / self.DT
                        DP[i][j] = DP[i][j] / AP
                        self.P[i][j] += self.OMEGA * DP[i][j]

                        if abs(DP[i][j]) > DMAX:
                            DMAX = abs(DP[i][j])
                            II = i
                            JJ = j
                self.Load_Pressure_Boundary(N, M)
            # IF (DMAX < TOL): GOTO 89

            # 89 CONTINUE

            for i in range(2, N):
                for j in range(2, M + 1):
                    self.U[i][j] += -self.DT * (self.P[i + 1][j] - self.P[i][j]) / self.DX1[i]

            for i in range(2, N + 1):
                for j in range(2, M):
                    self.V[i][j] += -self.DT * (self.P[i][j + 1] - self.P[i][j]) / self.DY1[j]

            self.Load_Vel_Boundary(N, M)

            TEMP = 0.
            TS = 0.
            for i in range(1, N + 2):
                for j in range(1, M + 2):
                    UTEMP = abs(self.U[i][j] - UN1[i][j])
                    VTEMP = abs(self.V[i][j] - VN1[i][j])
                    TS += np.square(UTEMP) + np.square(VTEMP)

                    # Recheck this if
                    if UTEMP > VTEMP:
                        if UTEMP > TEMP:
                            TEMP = UTEMP
                    elif (VTEMP > TEMP):
                        TEMP = VTEMP

                    UN1[i][j] = self.U[i][j]
                    VN1[i][j] = self.V[i][j]
            TS = np.sqrt(TS / 2. / (N + 2) / (M + 2))

        # WRITE

    def VOS(self, M, N):    # NOT CHECKED
        X_Center = 0    # Dummy
        Y_Center = 0    # Dummy
        Radius = 0.5    # Dummy
        Subgrid_Partition = 100
        Subgrid_Eta = 1. / np.square(Subgrid_Partition)
        for j in range(1, M+1):
            for i in range(1, N+1):
                X_Distance = (self.X[i] + self.X[i+1])/2. - X_Center
                Y_Distance = (self.Y[j] + self.Y[j+1])/2. - Y_Center
                X_Delta = self.X[i+1] - self.X[i]
                Y_Delta = self.Y[j+1] - self.Y[j]
                Distance = np.sqrt(np.square(X_Distance) + np.square(Y_Distance))
                Criterion = np.sqrt(np.square(X_Delta) + np.square(Y_Delta))

                # Simple Eta Calculation
                if (Distance > Radius):
                    self.Eta[i][j] = 0.
                else:
                    self.Eta[i][j] = 1.

                # Subgrid
                if abs(Distance-Radius) < Criterion:
                    Subgrid_X_Pos = np.linspace(self.X[i], self.X[i+1], Subgrid_Partition+1)
                    Subgrid_Y_Pos = np.linspace(self.Y[j], self.Y[j+1], Subgrid_Partition+1)
                    self.Eta[i][j] = 0.
                    for ii in range(Subgrid_Partition+1):
                        for jj in range(Subgrid_Partition+1):
                            Subgrid_X_Distance = (Subgrid_X_Pos[i] + Subgrid_X_Pos[i+1])/2. - X_Center
                            Subgrid_Y_Distance = (Subgrid_Y_Pos[j] + Subgrid_Y_Pos[j+1])/2. - Y_Center
                            Subgrid_Distance = np.sqrt(np.square(Subgrid_X_Distance) + np.square(Subgrid_Y_Distance))
                            if Subgrid_Distance < Radius:
                                self.Eta[i][j] += Subgrid_Eta

        # Write into ETA.dat
        File_Header = "VARIABLES=X,Y,E \nZONE I="+str(N)+",J="+str(M)
        File_Data = np.transpose(np.asarray([self.X, self.Y, self.Eta]))
        np.savetxt('ETA.dat', File_Data, header = File_Header, delimiter=" ")






# Main Function
MC = Main_Class(N, M)
t1 = time()
MC.Load_Input()
MC.Solver(N, M)
t2 = time()
print("Time taken by code was " .format(t2 - t1) + "seconds")
File = open('CLOCK.dat', "w+")
File.writelines('Time taken by code was' .format(t2 - t1) + 'seconds\n')
File.close()

