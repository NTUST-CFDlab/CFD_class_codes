/* ---------------------------------------------------------------
# Program Cylinder
#
#	THIS PROGRAM IS FOR SOLVING UNIFORM FLOW PAST A SQUARE CYLINDER
#	USING SOLA METHOD
#
#	AUTHOR: M. J. CHERN   DATE:4 JULY,2001
#
#
#       STAGGERED GRID (MAC)
#
#       NON-UNIFORM GRID VERSION
#         DATE: 14 MAY, 2002
#
#
#        QUICK SCHEME
#        DATE: 18 SEPT., 2002
#
#
#       PROGRAM MODIFIED FOR AN OSCIALLATING FLOW PAST A SQUARE CYLINDER
#       DATE: 26 OCt. 2002
#
#       MODIFY BOUNDARY CONDITIONS
#       DATE: 26 Nov. 2002
#
#       CONVERT TO FORTRAN 90 FORMAT
#       DATE: 20 SEPTEMBER 2011
#
#       NATURAL CONVECTION
#       DATE: 4 JAN. 2015
#
#       SOLA Method is replaced by projection method
#       This program is for simultions of flow past a cylinder.
#       DATE: 14 May, 2015
#
#		Converted to C++ Code
#		DATE: 2 June 2023
#
#
# ---------------------------------------------------------------*/


#include<iostream>
#include<cstdlib>
#include<ctime>
#include<cmath>
#include<fstream>
#include<iomanip>
#include<sstream>
#include<cstring>
#include<chrono>
#include <math.h>


using namespace std;

int i, j;
const int N = 200;
const int M = 100;

double t1, t2;
double X[N + 5], Y[M + 5];
double U[N + 4][M + 4], V[N + 4][M + 4];
double U1[N + 4][M + 4], V1[N + 4][M + 4];
double U2[N + 4][M + 4], V2[N + 4][M + 4];
double UN1[N+4][M+4], VN1[N+4][M+4];
double PRES[N + 4][M + 4];
double ST[N+4][M+4], VORT[N+4][M+4];
double FUU[N+4][M+4], FVV[N+4][M+4];
double FUUN1[N+4][M+4], FVVN1[N+4][M+4];
double FUUN2[N+4][M+4], FVVN2[N+4][M+4];
double DP[N+4][M+4];
double DX[N + 4], DX1[N + 4], DY[M + 4], DY1[M + 4];
double TIME, PI, RE, DT, OMEGA;
int TTT, OT, FT, ITER, RERUN, REIT;

// IBM module
double Fx[N + 4][M + 4], Fy[N + 4][M + 4];
double totalFx, totalFy, cDrag, cLift ;
double ETA[N+4][M+4];
double XX, YY, XC_t, YC_t;
double USOLID1	, VSOLID1;
double USOLID = 0.0 , VSOLID = 0.0;
double XC=6.0, YC=5.0, R=0.5;


//-------------------------------------

void input() {
    ifstream infile;

    infile.open("XX.DAT");
    for (i = 2; i <= N+2 ; i++) {
        infile >> X[i] >> i;
    }
    infile.close();

    infile.open("YY.DAT");
    for (j = 2; j <= M+2 ; j++) {
        infile >> Y[j] >> i;
    }
    infile.close();

    X[1]=X[2]-(X[3]-X[2]);
    X[0]=X[1]-(X[2]-X[1]);
    X[N+3]=X[N+2]+X[N+2]-X[N+1];
    X[N+4]=X[N+3]+X[N+3]-X[N+2];

    Y[1]=Y[2]-(Y[3]-Y[2]);
    Y[0]=Y[1]-(Y[2]-Y[1]);
    Y[M+3]=Y[M+2]+Y[M+2]-Y[M+1];
    Y[M+4]=Y[M+3]+Y[M+3]-Y[M+2];

//	DEFINE EACH OF THE DIRECTIONAL GRID LENGTHS
    for (i = 0; i <= N+3; i++) {
        DX[i] = X[i + 1] - X[i];
	}

    for (i = 0; i <= N+2; i++) {
		DX1[i] = 0.5 * (X[i + 2] - X[i]);
	}

    for (j = 0; j <= M+3; j++) {
        DY[j] = Y[j + 1] - Y[j];
    }

    for (j = 0; j <= M+2; j++) {
        DY1[j] = 0.5 * (Y[j + 2] - Y[j]);
    }



//
//	Inserting parameters from PARA.TXT
//

    infile.open("PARA.F");

    if (!infile.is_open()) {
        cerr << "Failed to open file: " << endl;
    }

    string line;
 
    if (getline(infile, line)) {
       istringstream iss(line);
        string token;

        if (getline(iss, token, ',')) {
            TTT = stoi(token);
        }

        if (getline(iss, token, ',')) {
            OT = stoi(token);
        }

        if (getline(iss, token, ',')) {
            DT = stod(token);
        }
		
		if (getline(iss, token, ',')) {
            FT = stoi(token);
        }
		
		if (getline(iss, token, ',')) {
            ITER = stoi(token);
        }
		
		if (getline(iss, token, ',')) {
            RE = stod(token);
        }
		
		if (getline(iss, token, ',')) {
            OMEGA = stod(token);
        }
		
		if (getline(iss, token, ',')) {
            RERUN = stoi(token);
        }
    }

    infile.close();


    TIME = 0.0;

    for (i = 0; i <= N + 3; i++) {
        for (j = 0; j <= M + 3; j++) {
            U[i][j] = 1.0;
            V[i][j] = 0.0;
            PRES[i][j] = 0.0;
        }
    }
}

//-------------------------------------

void boundary()
{
	PI = acos(-1.0);

	// DEFINE U(N,Y),V(N,Y)
	for (j = 0; j <= M+3; j++) {
        U[N+1][j] = U[N][j];
		U[N+2][j] = U[N+1][j];
		U[N+3][j] = U[N+2][j];
		V[N+2][j] = V[N+1][j];
        V[N+3][j] = V[N+2][j];
    }


	// DEFINE U(0,Y),V(0,Y)
    for (j = 0; j <= M+3; j++) {
        U[1][j] = 1.0;
        U[0][j] = U[1][j];
		V[1][j] = -V[2][j];
        V[0][j] = V[1][j];
	}


	// DEFINE U(X,0),V(X,0)


    for (i = 0; i <= N+3; i++) {
        U[i][1] = U[i][2];
        U[i][0] = U[i][1];
        V[i][1] = 0.0;
        V[i][0] = V[i][1];
    }


	// DEFINE U(X,M),V(X,M)
    for (i = 0; i <= N+3; i++) {
        U[i][M+2] = U[i][M+1];
        U[i][M+3] = U[i][M+2];
        V[i][M+1] = 0.0;
        V[i][M+2] = V[i][M+1];
		V[i][M+3] = V[i][M+2];
    }
}




//-------------------------------------


void pressure_boundary()
{
	
	for (j = 0; j <= M+3; j++) {
        PRES[1][j] = PRES[2][j];
        PRES[0][j] = PRES[1][j];
		PRES[N+2][j] = PRES[N+1][j];
        PRES[N+3][j] = PRES[N+2][j];
    }

    for (i = 0; i <= N+3; i++) {
        PRES[i][1] = PRES[i][2];
        PRES[i][0] = PRES[i][1];
		PRES[i][M+2] = PRES[i][M+1];
        PRES[i][M+3] = PRES[i][M+2];
    }


}


//-------------------------------------



void VOS() {
    int i, j, ii, jj;
    long double DISTANCE, CRITERION;
    long double SUBDX, SUBDY;
    long double SUBX[101];
    long double SUBY[101];

    ofstream ETAout("ETA.dat");
    ETAout << "VARIABLES=X,Y,E" << endl;
    ETAout << "ZONE I=" << N << ",J=" << M << endl;

    for (j = 1; j <= M+2; j++) {
        for (i = 1; i <= N+2; i++) {
            DISTANCE = sqrt((pow((X[i] + X[i+1]) / 2.0 - XC, 2.0)) +
                            (pow((Y[j] + Y[j+1]) / 2.0 - YC, 2.0)));
            CRITERION = sqrt(pow(X[i+1] - X[i], 2.0) + pow(Y[j+1] - Y[j], 2.0));

            if (DISTANCE > R) {
                ETA[i][j] = 0.0;
            }
            else {
                ETA[i][j] = 1.0;
            }


            if (fabs(DISTANCE - R) < CRITERION) {
                SUBX[1] = X[i];
                SUBY[1] = Y[j];
                SUBDX = (X[i+1] - X[i]) / 99.0;
                SUBDY = (Y[j+1] - Y[j]) / 99.0;

                for (ii = 2; ii <= 100; ii++) {
                    SUBX[ii] = SUBX[ii-1] + SUBDX;
                }


                for (jj = 2; jj <= 100; jj++) {
                    SUBY[jj] = SUBY[jj-1] + SUBDY;
                }
 
                ETA[i][j] = 0.0;

                for (ii = 1; ii <= 99; ii++) {
                    for (jj = 1; jj <= 99; jj++) {
                        DISTANCE = sqrt((pow((SUBX[ii+1] + SUBX[ii]) / 2.0 - XC, 2.0)) +
                                        (pow((SUBY[jj+1] + SUBY[jj]) / 2.0 - YC, 2.0)));
                        if (DISTANCE < R) {
                            ETA[i][j] += 1.0;
                        }
                    }
                }

                ETA[i][j] = ETA[i][j]/10000.0;
            }
       
            ETAout << X[i] << " " << Y[j] << " " << ETA[i][j] << endl;
        }
    }

    ETAout.close();
}




//-------------------------------------


void quick() {
    double FUX, FUY, FVX, FVY;
    double VISX, VISY, VDX, VDY;
    double UE, UE1, UNN, UW, UW1, US1;
    double VN, VE1, VNN, VS, VW1, VS1;
    int I, J;

    // First loop: Calculate FUU
	for (I = 2; I <= N+1; I++) {
        for (J = 2; J <= M+1; J++) {
            UE = 0.5 * (U[I + 1][J] + U[I][J]);
            UW = 0.5 * (U[I - 1][J] + U[I][J]);
            VN = 0.5 * (V[I][J] + V[I + 1][J]);
            VS = 0.5 * (V[I][J - 1] + V[I + 1][J - 1]);

            if (UE > 0) {
                UE1 = 0.5 * (U[I][J] + U[I + 1][J]) -
                      0.125 * DX[I + 1] * DX[I + 1] / DX1[I] *
                      ((U[I + 1][J] - U[I][J]) / DX[I + 1] -
                       (U[I][J] - U[I - 1][J]) / DX[I]);
            } else {
                UE1 = 0.5 * (U[I][J] + U[I + 1][J]) -
                      0.125 * DX[I + 1] * DX[I + 1] / DX1[I + 1] *
                      ((U[I + 2][J] - U[I + 1][J]) / DX[I + 2] -
                       (U[I + 1][J] - U[I][J]) / DX[I + 1]);
            }

            if (UW > 0) {
                UW1 = 0.5 * (U[I - 1][J] + U[I][J]) -
                      0.125 * DX[I] * DX[I] / DX1[I - 1] *
                      ((U[I][J] - U[I - 1][J]) / DX[I] -
                       (U[I - 1][J] - U[I - 2][J]) / DX[I - 1]);
            } else {
                UW1 = 0.5 * (U[I - 1][J] + U[I][J]) -
                      0.125 * DX[I] * DX[I] / DX1[I] *
                      ((U[I + 1][J] - U[I][J]) / DX[I + 1] -
                       (U[I][J] - U[I - 1][J]) / DX[I]);
            }

            if (VN > 0) {
                UNN = 0.5 * (U[I][J] + U[I][J + 1]) -
                      0.125 * DY1[J] * DY1[J] / DY[J] *
                      ((U[I][J + 1] - U[I][J]) / DY1[J] -
                       (U[I][J] - U[I][J - 1]) / DY1[J - 1]);
            } else {
                UNN = 0.5 * (U[I][J] + U[I][J + 1]) -
                      0.125 * DY1[J] * DY1[J] / DY[J + 1] *
                      ((U[I][J + 2] - U[I][J + 1]) / DY1[J + 1] -
                       (U[I][J + 1] - U[I][J]) / DY1[J]);
            }

            if (VS > 0) {
                US1 = 0.5 * (U[I][J - 1] + U[I][J]) -
                      0.125 * DY1[J - 1] * DY1[J - 1] / DY[J - 1] *
                      ((U[I][J] - U[I][J - 1]) / DY1[J - 1] -
                       (U[I][J - 1] - U[I][J - 2]) / DY1[J - 2]);
            } else {
                US1 = 0.5 * (U[I][J - 1] + U[I][J]) -
                      0.125 * DY1[J - 1] * DY1[J - 1] / DY[J] *
                      ((U[I][J + 1] - U[I][J]) / DY1[J] -
                       (U[I][J] - U[I][J - 1]) / DY1[J - 1]);
            }

            FUX = (UE * UE1 - UW * UW1) / DX1[I];
            FUY = (VN * UNN - VS * US1) / DY[J];
            VDX = ((U[I + 1][J] - U[I][J]) / DX[I + 1] -
                   (U[I][J] - U[I - 1][J]) / DX[I]) / DX1[I];
            VDY = ((U[I][J + 1] - U[I][J]) / DY1[J] -
                   (U[I][J] - U[I][J - 1]) / DY1[J - 1]) / DY[J];
            VISX = (VDX + VDY) / RE;

            FUU[I][J] = DT * (-FUX - FUY + VISX);
        }
    }

    // Second loop: Calculate FVV
    for (I = 2; I <= N+1; I++) {
        for (J = 2; J <= M+1; J++) {
            UE = 0.5 * (U[I][J] + U[I][J + 1]);
            UW = 0.5 * (U[I - 1][J] + U[I - 1][J + 1]);
            VN = 0.5 * (V[I][J] + V[I][J + 1]);
            VS = 0.5 * (V[I][J - 1] + V[I][J]);

            if (UE > 0) {
                VE1 = 0.5 * (V[I][J] + V[I + 1][J]) -
                      0.125 * DX1[I] * DX1[I] / DX[I] *
                      ((V[I + 1][J] - V[I][J]) / DX1[I] -
                       (V[I][J] - V[I - 1][J]) / DX1[I - 1]);
            } else {
                VE1 = 0.5 * (V[I][J] + V[I + 1][J]) -
                      0.125 * DX1[I] * DX1[I] / DX[I + 1] *
                      ((V[I + 2][J] - V[I + 1][J]) / DX1[I + 1] -
                       (V[I + 1][J] - V[I][J]) / DX1[I]);
            }

            if (UW > 0) {
                VW1 = 0.5 * (V[I - 1][J] + V[I][J]) -
                      0.125 * DX1[I - 1] * DX1[I - 1] / DX[I - 1] *
                      ((V[I][J] - V[I - 1][J]) / DX1[I - 1] -
                       (V[I - 1][J] - V[I - 2][J]) / DX1[I - 2]);
            } else {
                VW1 = 0.5 * (V[I - 1][J] + V[I][J]) -
                      0.125 * DX1[I - 1] * DX1[I - 1] / DX[I] *
                      ((V[I + 1][J] - V[I][J]) / DX1[I] -
                       (V[I][J] - V[I - 1][J]) / DX1[I - 1]);
            }

            if (VN > 0) {
                VNN = 0.5 * (V[I][J] + V[I][J + 1]) -
                      0.125 * DY[J + 1] * DY[J + 1] / DY1[J] *
                      ((V[I][J + 1] - V[I][J]) / DY[J + 1] -
                       (V[I][J] - V[I][J - 1]) / DY[J]);
            } else {
                VNN = 0.5 * (V[I][J] + V[I][J + 1]) -
                      0.125 * DY[J + 1] * DY[J + 1] / DY1[J + 1] *
                      ((V[I][J + 2] - V[I][J + 1]) / DY[J + 2] -
                       (V[I][J + 1] - V[I][J]) / DY[J + 1]);
            }

            if (VS > 0) {
                VS1 = 0.5 * (V[I][J - 1] + V[I][J]) -
                      0.125 * DY[J] * DY[J] / DY1[J - 1] *
                      ((V[I][J] - V[I][J - 1]) / DY[J] -
                       (V[I][J - 1] - V[I][J - 2]) / DY[J - 1]);
            } else {
                VS1 = 0.5 * (V[I][J - 1] + V[I][J]) -
                      0.125 * DY[J] * DY[J] / DY1[J] *
                      ((V[I][J + 1] - V[I][J]) / DY[J + 1] -
                       (V[I][J] - V[I][J - 1]) / DY[J]);
            }

            FVX = (UE * VE1 - UW * VW1) / DX[I];
            FVY = (VN * VNN - VS * VS1) / DY1[J];
            VDX = ((V[I + 1][J] - V[I][J]) / DX1[I] -
                   (V[I][J] - V[I - 1][J]) / DX1[I - 1]) / DX[I];
            VDY = ((V[I][J + 1] - V[I][J]) / DY[J + 1] -
                   (V[I][J] - V[I][J - 1]) / DY[J]) / DY1[J];
            VISY = (VDX + VDY) / RE;

            FVV[I][J] = DT * (-FVX - FVY + VISY);
        }
    }
}

//-------------------------------------

void solver() {
	double DMAX, TEMP, TS;
	double UTEMP, VTEMP;
	double TOL = 1.0e-3;
	double DD, AP, AN, AS, AW, AE;
	int TITE, PPPP;
	char LASTFILE[12];

    ofstream flow("flow.dat");
  

    // Open file in append mode for TECPLOT360
    ofstream file("CD_Time.dat", std::ios::app);
    if (file.is_open()) {
        file << " TITLE     = \"\" \n";
        file << " VARIABLES = t*,C<sub>D</sub>,C<sub>L</sub>\n";
        file.close();
    }

 
    REIT=1  ;
 
    for (i = 0; i <= N+3; i++) {
        for (j = 0; j <= M+3; j++) {
			UN1[i][j]=U[i][j];
			VN1[i][j]=V[i][j];
            FUUN1[i][j] = 0.0;
            FUUN2[i][j] = 0.0;
            FVVN1[i][j] = 0.0;
            FVVN2[i][j] = 0.0;
            Fx[i][j] = 0.0;
            Fy[i][j] = 0.0;
        }
    }
	
    if (RERUN == 1) {
        strcpy(LASTFILE, "LAST.DAT");
        ifstream infile(LASTFILE);
        infile >> TIME;
        infile >> REIT;
		for (j = 2; j <= M+1; j++) {
			for (i = 2; i <= N+1; i++) {
                infile >> U[i][j] >> V[i][j] >> PRES[i][j];
            }
        }
		for (j = 2; j <= M+1; j++) {
			for (i = 2; i <= N+1; i++) {
                infile >> FUUN1[i][j] >> FUUN2[i][j] >> FVVN1[i][j] >> FVVN2[i][j];
            }
        }
        infile.close();
        REIT++;
    }


    // Uncomment this section for CSV/PARAVIEW
    /*
    std::ofstream csvFile("CD_Time.csv", std::ios::app);
    if (csvFile.is_open()) {
        csvFile << " Time,CD,CL \n";
        csvFile.close();
    }
    */

  
    // Time stepping loop
    for (TITE = REIT; TITE <= TTT; TITE++) {
        TIME += DT;
        cout << "TIME = " << TIME << endl;
  
//   VOS();		// For a moving solid
    
    
//       PREDICTION
//       SOLVING VELOCITY FIELD
//       USING QUICK SCHEME

    quick();
  
 
	for(i=2; i<= N+1; i++){
		for(j=2; j<= M+1; j++){
			if(REIT == 1){
				U[i][j] = U[i][j] + FUU[i][j];
			}
			else{
				if(REIT == 2){
					U[i][j] = U[i][j] + 1.5*FUU[i][j] - 0.5*FUUN1[i][j];
				}
				else{
					U[i][j] = U[i][j] + (23.*FUU[i][j] - 16.*FUUN1[i][j] + 5.*FUUN2[i][j])/12.;
				}
			}
        FUUN2[i][j] = FUUN1[i][j];
        FUUN1[i][j] = FUU[i][j];
		}
	}
  
	for(i=2; i<= N+1; i++){
		for(j=2; j<= M+1; j++){
			if(REIT == 1){
				V[i][j] = V[i][j] + FVV[i][j];
			}
			else{
				if(REIT == 2){
					V[i][j] = V[i][j] + 1.5*FVV[i][j] - 0.5*FVVN1[i][j];
				}
				else{
					V[i][j] = V[i][j] + (23.*FVV[i][j] - 16.*FVVN1[i][j] + 5.*FVVN2[i][j])/12.;
				}
			}
        FVVN2[i][j] = FVVN1[i][j];
        FVVN1[i][j] = FVV[i][j];
		}
	}
	
	boundary();

	
//
//     U,V,W AND P ---- PROJECTION METHOD
//
	
    PPPP = 0;
    DMAX = 1.0;

	while (DMAX > TOL && PPPP < ITER) {
    
    PPPP = PPPP + 1;
    DMAX = 0.0;

	for (i = 2; i <= N+1; i++) {
		for (j = 2; j <= M+1; j++) {            
			DD = (U[i][j] - U[i-1][j]) * DY[j] + (V[i][j] - V[i][j-1]) * DX[i];
			AP = -DY[j] / DX1[i] - DY[j] / DX1[i-1] - DX[i] / DY1[j] - DX[i] / DY1[j-1];
			AE = DY[j] / DX1[i];
			AW = DY[j] / DX1[i-1];
			AN = DX[i] / DY1[j];
			AS = DX[i] / DY1[j-1];
			DP[i][j] = -AP * PRES[i][j] - AE * PRES[i+1][j] - AW * PRES[i-1][j] 
						- AN * PRES[i][j+1] - AS * PRES[i][j-1] + DD / DT;
			DP[i][j] /= AP;
			PRES[i][j] += OMEGA * DP[i][j];

				DMAX = fmax(fabs(DP[i][j]), DMAX);
		}
	}
	}
	
	cout << "DMAX = " << DMAX << endl;


    pressure_boundary();
	
	
	totalFx = 0.0;
	for (i = 2; i <= N+1; i++) {
		for (j = 2; j <= M+1; j++) {
			U1[i][j] = U[i][j] - DT * (PRES[i + 1][j] - PRES[i][j]) / DX1[i];
			USOLID1 = USOLID;
			U2[i][j] = 0.5 * (ETA[i + 1][j] + ETA[i][j]) * USOLID1 + (1.0 - 0.5 * (ETA[i + 1][j] + ETA[i][j])) * U1[i][j];
			Fx[i][j] = (U2[i][j] - U1[i][j]) / DT;
			totalFx += (Fx[i][j] * (DX[i] * DY[j]));
			U[i][j] = U2[i][j];
		}
	}

	totalFy = 0.0;
	for (i = 2; i <= N+1; i++) {
		for (j = 2; j <= M+1; j++) {
			V1[i][j] = V[i][j] - DT * (PRES[i][j + 1] - PRES[i][j]) / DY1[j];
			VSOLID1 = VSOLID;
			V2[i][j] = 0.5 * (ETA[i][j + 1] + ETA[i][j]) * VSOLID1 + (1.0 - 0.5 * (ETA[i][j + 1] + ETA[i][j])) * V1[i][j];
			Fy[i][j] = (V2[i][j] - V1[i][j]) / DT;
			totalFy += (Fy[i][j] * (DX[i] * DY[j]));
			V[i][j] = V2[i][j];
		}
	}

	cDrag = -2.0 * totalFx;  // cDrag = 2 * totalFx / (rho * U^2 * D)
	cLift = -2.0 * totalFy;  // cLift = 2 * totalFy / (rho * U^2 * D)


	if (TIME >= 0.1) {
		ofstream file("CD_Time.dat", std::ios::app);
		if (file.is_open()) {
			file << static_cast<float>(TIME) << "," 
				<< static_cast<float>(cDrag) << "," 
				<< static_cast<float>(cLift) << "\n";
			file.close();
		}
	}


	boundary();

	
//-------------------------------------


	TEMP = 0.0;
	TS = 0.0;

	for (i = 0; i <= N + 3; i++) {
		for (j = -1; j <= M + 2; j++) {
			UTEMP = fabs(U[i][j] - UN1[i][j]);
			VTEMP = fabs(V[i][j] - VN1[i][j]);
			TS += UTEMP * UTEMP + VTEMP * VTEMP;
			TEMP = fmax(UTEMP, fmax(VTEMP, TEMP));
			UN1[i][j] = U[i][j];
			VN1[i][j] = V[i][j];
		}
	}
      TS = sqrt(TS / (2.0 * (N + 1) * (M + 1)));


	cout << "UV-P ITERATION NUMBER = " << PPPP << endl;
	if (TITE % FT == 0) {
		flow << TITE << " " << TIME << " " << PPPP <<" "<< DMAX << endl;
	}

//
//     OUTPUT NUMERICAL RESULTS
//
	
	if (TITE % OT == 0) {
		ostringstream filename_stream;
		filename_stream << setfill('0');
		filename_stream << setw(5) << TITE / OT;
		string filename = "CA" + filename_stream.str()+".TEC";
			if (TITE / OT < 10) filename.replace(2, 4, "0000");
			if (TITE / OT < 100) filename.replace(2, 3, "000");
			if (TITE / OT < 1000) filename.replace(2, 2, "00");
			if (TITE / OT < 10000) filename.replace(2, 1, "0");
		ofstream file(filename.c_str());

		for (i = 1; i <= N+1; i++) {
			for (j = 1; j <= M+1; j++) {
				ST[i][j] = 0.0;
				VORT[i][j] = 0.0;
			}
		}

		for (i = 2; i <= N; i++) {
			for (j = 2; j <= M; j++) {
				ST[i][j] = ST[i][j - 1] + (Y[j + 1] - Y[j]) * U[i][j];
				VORT[i][j] = -(U[i - 1][j] - U[i - 1][j - 1]) / (0.5 * (Y[j + 1] - Y[j - 1])) +
							(V[i][j - 1] - V[i - 1][j - 1]) / (0.5 * (X[i + 1] - X[i - 1]));
			}
		}

		file << "TITLE=\"FLOW PAST A CYLINDER\"" << endl;
		file << "VARIABLES=X,Y,ETA,U,V,P,Fx,Fy,ST,VORT" << endl;
		file << "ZONE T=\"FLOW\", I=" << N << ", J=" << M << ", F=POINT" << endl;
		file << "SOLUTIONTIME=" << TIME << endl;

		for (j = 2; j <= M+1; j++) {
			for (i = 2; i <= N+1; i++) {
				file << fixed << setprecision(8) << (X[i] + X[i + 1]) / 2.0 << " " << (Y[j] + Y[j + 1]) / 2.0 << " "
                     << ETA[i][j] << " " << (U[i][j] + U[i-1][j]) / 2.0 << " " << (V[i][j] + V[i][j-1]) / 2.0 << " " 
					 << PRES[i][j] << " " << (Fx[i][j]+Fx[i-1][j]) / 2.0 << " " << (Fy[i][j]+Fy[i][j-1]) / 2.0 << " "
					 << ST[i][j] << " " << VORT[i][j] <<"\n";
			}
		}


		ofstream REFILE("LAST.DAT");
		REFILE << TIME << '\n';
		REFILE << TITE << '\n';
		for (j = 2; j <= M+1; j++) {
			for (i = 2; i <= N+1; i++) {
				REFILE << U[i][j] << ' ' << V[i][j] << ' ' << PRES[i][j] << '\n';
			}
		}
		for (j = 2; j <= M+1; j++) {
			for (i = 2; i <= N+1; i++) {
				REFILE << FUUN1[i][j] << ' ' << FUUN2[i][j] << ' ' << FVVN1[i][j] << ' ' << FVVN2[i][j] << '\n';
			}
		}
		REFILE.close();
		file.close();
	}
	}
	flow.close();
}

//-------------------------------------

int main() {


    ifstream in_file("CLOCK.DAT");
    ofstream out_file("CLOCK.OUT");
  
    clock_t t1 = clock();

    input();
    cout << "INPUT PASS" << endl;
    
    VOS();
	cout << "INITIAL VOS PASS" << endl;
	
    solver();
  
    clock_t t2 = clock();
    double elapsed_secs = double(t2 - t1) / CLOCKS_PER_SEC;
    out_file << "Elapsed wall-clock time: " << elapsed_secs << " seconds" << std::endl;
    cout << "SOLVER PASS" << endl;

	out_file.close();

    return 0;
}
