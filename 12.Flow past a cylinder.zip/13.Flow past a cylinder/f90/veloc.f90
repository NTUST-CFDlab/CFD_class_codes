!
!
!       AUTHOR:M J CHERN      17 MAY,1996
        PROGRAM STREAM
        PARAMETER (N=201,M=101)
        DOUBLE PRECISION :: U(0:N,0:M),V(0:N,0:M),P(0:N,0:M), TEM(0:N,0:M)
        DOUBLE PRECISION :: Fx(0:N,0:M),Fy(0:N,0:M)                           ! MY PLUS
        DOUBLE PRECISION :: QF(0:N,0:M)
        DOUBLE PRECISION :: Y(-1:M+1),X(-1:N+1)
        DOUBLE PRECISION :: PI
        INTEGER I,J
        PI=DCOS(-1.D0)
        OPEN(UNIT=15,FILE='CA00283.DAT')
        OPEN(UNIT=16,FILE='YY.DAT')
        OPEN(UNIT=17,FILE='VELRE100.DAT')
        OPEN(UNIT=18,FILE='XX.DAT')
        OPEN(UNIT=19,FILE='FORCE.DAT')
        DO J=0,M,1
                DO  I=0,N,1
                  READ(15,*) U(I,J),V(I,J),P(I,J),TEM(I,J),FX(I,J),FY(I,J),QF(I,J)
                END DO
       END DO
        DO 300 J=-1,M+1,1
                READ(16,*)Y(J)
300     CONTINUE
        DO 800 I=-1,N+1,1
                READ(18,*)X(I)
800     CONTINUE
        WRITE(17,*)'TITLE="VELOCITY VECTOR FIELD"'
        WRITE(17,*)'VARIABLES=X,Y,U,V,P, TEM'
        WRITE(17,*)'ZONE T="XYZ", I=',N,' ,J=',M,' ,F=POINT'
        DO 600 J=0,M-1,1
                DO 700 I=0,N-1,1
        WRITE(17,98)(X(I)+X(I+1))/2.,(Y(J)+Y(J+1))/2.,U(I,J),V(I,J),P(I,J), TEM(I,J)
700             CONTINUE
600     CONTINUE

        WRITE(19,*)'TITLE="FORCE FIELD"'
        WRITE(19,*)'VARIABLES=X,Y,FX,FY,QF'
        WRITE(19,*)'ZONE T="XYZ", I=',N-1,' ,J=',M-1,' ,F=POINT'
        DO 900 J=1,M-1,1
                DO 1000 I=1,N-1,1
        WRITE(19,99)(X(I)+X(I+1))/2.,(Y(J)+Y(J+1))/2.,FX(I,J),FY(I,J), QF(I,J)
1000             CONTINUE
900     CONTINUE


98      FORMAT(6(E15.7,1X))
99      FORMAT(5(E15.7,1X))
        CLOSE(17)
        CLOSE(16)
        CLOSE(15)
        CLOSE(19)
        END PROGRAM STREAM
