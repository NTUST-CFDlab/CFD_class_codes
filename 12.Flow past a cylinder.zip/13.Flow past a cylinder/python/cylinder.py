# ---------------------------------------------------------------
# Program Flow
#
#	THIS PROGRAM IS FOR SOLVING UNIFORM FLOW PAST A SQUARE CYLINDER
#	USING SOLA METHOD
#
#	AUTHOR: M. J. CHERN   DATE:4 JULY,2001
#
#
#       STAGGERED GRID (MAC)
#
#       NON-UNIFORM GRID VERSION
#         DATE: 14 MAY, 2002
#
#
#        QUICK SCHEME
#        DATE: 18 SEPT., 2002
#
#
#       PROGRAM MODIFIED FOR AN OSCIALLATING FLOW PAST A SQUARE CYLINDER
#       DATE: 26 OCt. 2002
#
#       MODIFY BOUNDARY CONDITIONS
#       DATE: 26 Nov. 2002
#
#       CONVERT TO FORTRAN 90 FORMAT
#       DATE: 20 SEPTEMBER 2011
#
#       NATURAL CONVECTION
#       DATE: 4 JAN. 2015
#
#       SOLA Method is replaced by projection method
#       This program is for cavity flow simualtions.
#       DATE: 14 May, 2015
#
#		Converted to Python Code
#		DATE: 7 May 2026
# ---------------------------------------------------------------

# Import
import numpy as np
from time import time

# Main Parameters
N = 200
M = 100

# Class (with function = Load_Input, Load_Velocity_Boudnary, Load_Pressure Boundary, QUICK, Solver)
class Main_Class():
    def __init__(self, N, M):
        # M & N are always transfered just to make it short (N instead of self.N)
        # Conversion:
        #	-1 to N+1	--> nx = N+3, ny = M+3
        #	-1 to N 	--> nx = N+2
        #	0  to N		--> nx = N+1
        # Example N = 2 --> n(-1 to 3) = 5

        # File Names
        self.x_Mesh_File = "XX.dat"
        self.y_Mesh_File = "YY.dat"
        self.Parameter_File = "PARA.F"

        # Solid velocity
        self.USOLID = 0.0
        self.VSOLID = 0.0

        # Main Variables
        self.U = np.zeros((N + 3, M + 3))
        self.V = np.zeros((N + 3, M + 3))
        self.P = np.zeros((N + 3, M + 3))
        self.ETA = np.zeros((N + 3, M + 3))

        # Derivatives Vars
        self.DX = np.zeros(N + 3)
        self.DX1 = np.zeros(N + 3)
        self.DY = np.zeros(M + 3)
        self.DY1 = np.zeros(M + 3)

    def Load_Input(self):
        self.X = np.float64(np.loadtxt(self.x_Mesh_File, usecols=(0)))
        self.Y = np.float64(np.loadtxt(self.y_Mesh_File, usecols=(0)))
        nx = len(self.X)
        ny = len(self.Y)

        for i in range(nx - 1):
            self.DX[i] = self.X[i + 1] - self.X[i]
        for i in range(nx - 2):
            self.DX1[i] = 0.5 * (self.X[i + 2] - self.X[i])

        for j in range(ny - 1):
            self.DY[j] = self.Y[j + 1] - self.Y[j]
        for j in range(ny - 2):
            self.DY1[j] = 0.5 * (self.Y[j + 2] - self.Y[j])

        TempT = np.loadtxt(self.Parameter_File, delimiter=',', max_rows=1)
        self.TTT, self.OT, self.DT, self.FT = int(TempT[0]), int(TempT[1]), TempT[2], int(TempT[3])
        self.ITER, self.RE, self.OMEGA, self.RERUN = int(TempT[4]), TempT[5], TempT[6], int(TempT[7])

        self.Time = 0.
        self.U[:,:] = 1.
        self.V[:,:] = 0.
        self.P[:,:] = 0.

    def Load_Vel_Boundary(self, N, M):
        # Left
        self.U[1,1:M+2] = 1.
        self.U[0,1:M+2] = self.U[1,1:M+2]
        self.V[1,1:M+2] = -self.V[2,1:M+2]
        self.V[0,1:M+2] = self.V[1,1:M+2]

        # Right
        self.U[N,1:M+2] = self.U[N - 1,1:M+2]
        self.U[N + 1,1:M+2] = self.U[N,1:M+2]
        self.V[N + 1,1:M+2] = self.V[N,1:M+2]
        self.V[N + 2,1:M+2] = self.V[N + 1,1:M+2]

        # Bot
        self.U[2:N+2,1] = self.U[2:N+2,2]
        self.U[2:N+2,0] = self.U[2:N+2,1]
        self.V[2:N+2,1] = 0.
        self.V[2:N+2,0] = self.V[2:N+2,0]

        # Top
        self.U[1:N+2,M + 1] = self.U[1:N+2,M]
        self.U[1:N+2,M + 2] = self.U[1:N+2,M + 1]
        self.V[1:N+2,M] = 0.
        self.V[1:N+2,M + 1] = self.V[1:N+2,M]

    def Load_Pressure_Boundary(self, N, M):
        self.P[1,1:M+2] = self.P[2,1:M+2]
        self.P[N+1,1:M+2] = self.P[N,1:M+2]
        self.P[2:N+2,1] = self.P[2:N+2,2]
        self.P[2:N+2,M+1] = self.P[2:N+2,M]

    def VOS(self, N, M):
        X_Center = 6.   
        Y_Center = 5.    
        Radius = 0.5   
        Subgrid_Partition = 100
        Subgrid_Eta = 1. / np.square(Subgrid_Partition)
        for j in range(1, M+1):
            for i in range(1, N+1):
                X_Distance = (self.X[i] + self.X[i+1])/2. - X_Center
                Y_Distance = (self.Y[j] + self.Y[j+1])/2. - Y_Center
                X_Delta = self.X[i+1] - self.X[i]
                Y_Delta = self.Y[j+1] - self.Y[j]
                Distance = np.sqrt(np.square(X_Distance) + np.square(Y_Distance))
                Criterion = np.sqrt(np.square(X_Delta) + np.square(Y_Delta))

                # Simple Eta Calculation
                if (Distance > Radius):
                    self.ETA[i,j] = 0.
                else:
                    self.ETA[i,j] = 1.

                # Subgrid
                if abs(Distance - Radius) < Criterion:
                    # Create the edges of the sub-cells
                    Subgrid_X_Pos = np.linspace(self.X[i], self.X[i+1], Subgrid_Partition + 1)
                    Subgrid_Y_Pos = np.linspace(self.Y[j], self.Y[j+1], Subgrid_Partition + 1)
                    
                    self.ETA[i, j] = 0.
                    
                    # Loop through the intervals (Subgrid_Partition cells)
                    for ii in range(Subgrid_Partition): 
                        for jj in range(Subgrid_Partition):
                            # Now ii+1 will correctly point to the last edge index
                            Subgrid_X_Distance = (Subgrid_X_Pos[ii] + Subgrid_X_Pos[ii+1]) / 2. - X_Center
                            Subgrid_Y_Distance = (Subgrid_Y_Pos[jj] + Subgrid_Y_Pos[jj+1]) / 2. - Y_Center
                            
                            Subgrid_Distance = np.sqrt(np.square(Subgrid_X_Distance) + np.square(Subgrid_Y_Distance))
                            
                            if Subgrid_Distance < Radius:
                                self.ETA[i, j] += Subgrid_Eta        


    def QUICK(self, N, M):
        FUU = np.zeros((N + 3, M + 3))
        FVV = np.zeros((N + 3, M + 3))

        for i in range(2, N):
            for j in range(2, M + 1):
                X1 = self.DX[i] / 2.
                X2 = self.DX[i + 1] / 2.
                X3 = self.DX[i + 1] + self.DX[i + 2] / 2.
                X4 = self.DX[i - 1] + self.DX[i] / 2.
                X5 = self.DX[i] / 2.
                X6 = self.DX[i - 1] / 2.
                X7 = self.DX[i - 1] + self.DX[i - 2] / 2.
                X8 = self.DX[i] + self.DX[i + 1] / 2.

                UE = 0.5 * (self.DX[i] * self.U[i + 1,j] / self.DX1[i] + self.DX[i + 1] * self.U[i,j] / self.DX1[i])
                if UE > 0.:
                    A1 = X2 * X4 / (X4 - X1) / (X1 + X2)
                    A2 = X1 * X4 / (X1 + X2) / (X2 + X4)
                    A3 = -X1 * X2 / (X4 - X1) / (X2 + X4)
                    UE1 = A1 * self.U[i,j] + A2 * self.U[i + 1,j] + A3 * self.U[i - 1,j]
                else:
                    A1 = -X1 * X3 / (X1 + X2) / (X2 - X3)
                    A2 = X2 * X3 / (X1 + X3) / (X1 + X2)
                    A3 = X1 * X2 / (X1 + X3) / (X2 - X3)
                    UE1 = A1 * self.U[i + 1,j] + A2 * self.U[i,j] + A3 * self.U[i + 2,j]

                UW = 0.5 * (self.DX[i] * self.U[i - 1,j] / self.DX1[i - 1] + self.DX[i - 1] * self.U[i,j] / self.DX1[i - 1])
                if UW > 0.:
                    A1 = X5 * X7 / (X7 - X6) / (X5 + X6)
                    A2 = X6 * X7 / (X5 + X7) / (X5 + X6)
                    A3 = -X5 * X6 / (X7 - X6) / (X5 + X7)
                    UW1 = A1 * self.U[i - 1,j] + A2 * self.U[i,j] + A3 * self.U[i - 2,j]
                else:
                    A1 = X6 * X8 / (X5 + X6) / (X8 - X5)
                    A2 = X5 * X8 / (X5 + X6) / (X6 + X8)
                    A3 = -X5 * X6 / (X6 + X8) / (X8 - X5)
                    UW1 = A1 * self.U[i,j] + A2 * self.U[i - 1,j] + A3 * self.U[i + 1,j]

                #print(UE, UE1, UW, UW1)
                FUX = (UE * UE1 - UW * UW1) / self.DX[i]

                Y1 = self.DY[j] / 2.
                Y2 = self.DY[j] / 2.
                Y3 = self.DY[j + 1] + self.DY[j] / 2.
                Y4 = self.DY[j - 1] + self.DY[j] / 2.
                Y5 = self.DY[j - 1] / 2.
                Y6 = self.DY[j - 1] / 2.
                Y7 = self.DY[j - 2] + self.DY[j - 1] / 2.
                Y8 = self.DY[j] + self.DY[j - 1] / 2.

                VN = 0.5 * (self.V[i,j] + self.V[i + 1,j])
                if VN > 0.:
                    A1 = Y2 * Y4 / (Y4 - Y1) / (Y1 + Y2)
                    A2 = Y1 * Y4 / (Y1 + Y2) / (Y2 + Y4)
                    A3 = -Y1 * Y2 / (Y4 - Y1) / (Y2 + Y4)
                    UNN = A1 * self.U[i,j] + A2 * self.U[i,j + 1] + A3 * self.U[i,j - 1]
                else:
                    A1 = -Y1 * Y3 / (Y1 + Y2) / (Y2 - Y3)
                    A2 = Y2 * Y3 / (Y1 + Y3) / (Y1 + Y2)
                    A3 = Y1 * Y2 / (Y1 + Y3) / (Y2 - Y3)
                    UNN = A1 * self.U[i,j + 1] + A2 * self.U[i,j] + A3 * self.U[i,j + 2]

                VS = 0.5 * (self.V[i,j - 1] + self.V[i + 1,j - 1])
                if VS > 0.:
                    A1 = Y5 * Y7 / (Y7 - Y6) / (Y5 + Y6)
                    A2 = Y6 * Y7 / (Y5 + Y7) / (Y5 + Y6)
                    A3 = -Y5 * Y6 / (Y7 - Y6) / (Y5 + Y7)
                    US1 = A1 * self.U[i,j - 1] + A2 * self.U[i,j] + A3 * self.U[i,j - 2]
                else:
                    A1 = Y6 * Y8 / (Y5 + Y6) / (Y8 - Y5)
                    A2 = Y5 * Y8 / (Y5 + Y6) / (Y6 + Y8)
                    A3 = -Y5 * Y6 / (Y6 + Y8) / (Y8 - Y5)
                    US1 = A1 * self.U[i,j] + A2 * self.U[i,j - 1] + A3 * self.U[i,j + 1]

                FUY = (VN * UNN - VS * US1) / self.DY1[j - 1]

                FUC = 0.
                VDX = (self.U[i + 1,j] - self.U[i,j]) / self.DX[i] - (self.U[i,j] - self.U[i - 1,j]) / self.DX[i - 1]
                VDX = VDX / self.DX1[i - 1]
                VDY = (self.U[i,j + 1] - self.U[i,j]) / self.DY1[j] - (self.U[i,j] - self.U[i,j - 1]) / self.DY1[j - 1]
                VDY = VDY / self.DY[j]
                VISX = (VDX + VDY) / self.RE
                FUU[i,j] = self.DT * (-FUX - FUY - FUC + VISX)

        for i in range(2, N + 1):
            for j in range(2, M):
                X1 = self.DX[i] / 2.
                X2 = self.DX[i] / 2.
                X3 = self.DX[i + 1] + self.DX[i] / 2.
                X4 = self.DX[i - 1] + self.DX[i] / 2.
                X5 = self.DX[i - 1] / 2.
                X6 = self.DX[i - 1] / 2.
                X7 = self.DX[i - 2] + self.DX[i - 1] / 2.
                X8 = self.DX[i] + self.DX[i - 1] / 2.

                UE = 0.5 * (self.U[i,j] + self.U[i,j + 1])
                if UE > 0.:
                    A1 = X2 * X4 / (X4 - X1) / (X1 + X2)
                    A2 = X1 * X4 / (X1 + X2) / (X2 + X4)
                    A3 = -X1 * X2 / (X4 - X1) / (X2 + X4)
                    VE1 = A1 * self.V[i,j] + A2 * self.V[i + 1,j] + A3 * self.V[i - 1,j]
                else:
                    A1 = -X1 * X3 / (X1 + X2) / (X2 - X3)
                    A2 = X2 * X3 / (X1 + X3) / (X1 + X2)
                    A3 = X1 * X2 / (X1 + X3) / (X2 - X3)
                    VE1 = A1 * self.V[i + 1,j] + A2 * self.V[i,j] + A3 * self.V[i + 2,j]

                UW = 0.5 * (self.U[i - 1,j] + self.U[i - 1,j + 1])
                if UW > 0.:
                    A1 = X5 * X7 / (X7 - X6) / (X5 + X6)
                    A2 = X6 * X7 / (X5 + X7) / (X5 + X6)
                    A3 = -X5 * X6 / (X7 - X6) / (X5 + X7)
                    VW1 = A1 * self.V[i - 1,j] + A2 * self.V[i,j] + A3 * self.V[i - 2,j]
                else:
                    A1 = X6 * X8 / (X5 + X6) / (X8 - X5)
                    A2 = X5 * X8 / (X5 + X6) / (X6 + X8)
                    A3 = -X5 * X6 / (X6 + X8) / (X8 - X5)
                    VW1 = A1 * self.V[i,j] + A2 * self.V[i - 1,j] + A3 * self.V[i + 1,j]

                FVX = (UE * VE1 - UW * VW1) / self.DX1[i - 1]
                Y1 = self.DY[j] / 2.
                Y2 = self.DY[j + 1] / 2.
                Y3 = self.DY[j + 1] + self.DY[j + 2] / 2.
                Y4 = self.DY[j - 1] + self.DY[j] / 2.
                Y5 = self.DY[j] / 2.
                Y6 = self.DY[j - 1] / 2.
                Y7 = self.DY[j - 1] + self.DY[j - 2] / 2.
                Y8 = self.DY[j] + self.DY[j + 1] / 2.

                VN = 0.5 * (self.DY[j + 1] * self.V[i,j] / self.DY1[j] + self.DY[j] * self.V[i,j + 1] / self.DY1[j])
                if VN > 0.:
                    A1 = Y2 * Y4 / (Y4 - Y1) / (Y1 + Y2)
                    A2 = Y1 * Y4 / (Y1 + Y2) / (Y2 + Y4)
                    A3 = -Y1 * Y2 / (Y4 - Y1) / (Y2 + Y4)
                    VNN = A1 * self.V[i,j] + A2 * self.V[i,j + 1] + A3 * self.V[i,j - 1]
                else:
                    A1 = -Y1 * Y3 / (Y1 + Y2) / (Y2 - Y3)
                    A2 = Y2 * Y3 / (Y1 + Y3) / (Y1 + Y2)
                    A3 = Y1 * Y2 / (Y1 + Y3) / (Y2 - Y3)
                    VNN = A1 * self.V[i,j + 1] + A2 * self.V[i,j] + A3 * self.V[i,j + 2]

                VS = 0.5 * (self.DY[j] * self.V[i,j - 1] / self.DY1[j - 1] + self.DY[j - 1] * self.V[i,j] / self.DY1[j - 1])
                if VS > 0.:
                    A1 = Y5 * Y7 / (Y7 - Y6) / (Y5 + Y6)
                    A2 = Y6 * Y7 / (Y5 + Y7) / (Y5 + Y6)
                    A3 = -Y5 * Y6 / (Y7 - Y6) / (Y5 + Y7)
                    VS1 = A1 * self.V[i,j - 1] + A2 * self.V[i,j] + A3 * self.V[i,j - 2]
                else:
                    A1 = Y6 * Y8 / (Y5 + Y6) / (Y8 - Y5)
                    A2 = Y5 * Y8 / (Y5 + Y6) / (Y6 + Y8)
                    A3 = -Y5 * Y6 / (Y6 + Y8) / (Y8 - Y5)
                    VS1 = A1 * self.V[i,j] + A2 * self.V[i,j - 1] + A3 * self.V[i,j + 1]

                FVY = (VN * VNN - VS * VS1) / self.DY[j]
                FVC = 0.
                VDX = (self.V[i + 1,j] - self.V[i,j]) / self.DX[i] - (self.V[i,j] - self.V[i - 1,j]) / self.DX[i - 1]
                VDX = VDX / self.DX1[i - 1]
                VDY = (self.V[i,j + 1] - self.V[i,j]) / self.DY1[j] - (self.V[i,j] - self.V[i,j - 1]) / self.DY1[j - 1]
                VDY = VDY / self.DY[j]
                VISY = (VDX + VDY) / self.RE
                FVV[i,j] = self.DT * (-FVX - FVY - FVC + VISY)

        return FUU, FVV

    def Solver(self, N, M):
        
        open("CD_Time.dat", "w").close()
        
        TIME = 0.
        REIT = 1
        TOL = 1e-4

        UN1 = np.copy(self.U)
        VN1 = np.copy(self.V)
        FUUN1 = np.zeros((N + 3, M + 3))
        FUUN2 = np.zeros((N + 3, M + 3))
        FVVN1 = np.zeros((N + 3, M + 3))
        FVVN2 = np.zeros((N + 3, M + 3))
        DP = np.zeros((N + 3, M + 3))

        if self.RERUN == 1:
            File_Holder = open('LAST.DAT', "r")
            Temp_All_Lines = File_Holder.readlines()
            TIME = float(Temp_All_Lines[0])
            REIT = float(Temp_All_Lines[1])

            i = 1
            j = 1
            Total = (N + 1) * ( M + 1)
            for k in range(Total):
                Splitted_Lines = Temp_All_Lines[2+k].split()
                self.U[i,j] = float(Splitted_Lines[0])
                self.V[i,j] = float(Splitted_Lines[1])
                self.P[i,j] = float(Splitted_Lines[2])

                Splitted_Lines = Temp_All_Lines[2+k+Total].split()
                FUUN1[i,j] = float(Splitted_Lines[0])
                FUUN2[i,j] = float(Splitted_Lines[1])
                FVVN1[i,j] = float(Splitted_Lines[2])
                FVVN2[i,j] = float(Splitted_Lines[3])

                j += 1
                if j == M+2:
                    j = 1
                    i += 1

            REIT += 1
            File_Holder.close()

        for TITE in range(REIT, self.TTT + 1):
            TIME += self.DT
            print("Time = " + str(TIME))

            FUU, FVV = self.QUICK(N, M)

            # 1 = First order (Euler), 2 = second order (Adam Bashforth), 3 = third order (Adam Bashforth)
            if REIT == 1:
                self.U[2: N, 2: M + 1] += FUU[2: N, 2: M + 1]
                self.V[2: N + 1, 2: M] += FVV[2: N + 1, 2: M]
            elif REIT == 2:
                self.U[2: N, 2: M + 1] += 1.5 * FUU[2: N, 2: M + 1] - 0.5 * FUUN1[2: N, 2: M + 1]
                self.V[2: N + 1, 2: M] += 1.5 * FVV[2: N + 1, 2: M]- 0.5 * FVVN1[2: N + 1, 2: M]
            else:
                self.U[2: N, 2: M + 1] += (23. * FUU[2: N, 2: M + 1] - 16. * FUUN1[2: N, 2: M + 1] + 5. * FUUN2[2: N, 2: M + 1]) / 12.
                self.V[2: N + 1, 2: M] += (23. * FVV[2: N + 1, 2: M] - 16. * FVVN1[2: N + 1, 2: M] + 5. * FVVN2[2: N + 1, 2: M]) / 12.
            FUUN2[2: N, 2: M + 1] = np.copy(FUUN1[2: N, 2: M + 1])
            FUUN1[2: N, 2: M + 1] = np.copy(FUU[2: N, 2: M + 1])
            FVVN2[2: N + 1, 2: M] = np.copy(FVVN1[2: N + 1, 2: M])
            FVVN1[2: N + 1, 2: M] = np.copy(FVV[2: N + 1, 2: M])

            self.Load_Vel_Boundary(N, M)

            for PPPP in range(1, self.ITER + 1):
                DMAX = 0.
                for i in range(2, N + 1):
                    for j in range(2, M + 1):
                        DD = (self.U[i,j] - self.U[i - 1,j]) * self.DY[j] \
                             + (self.V[i,j] - self.V[i,j - 1]) * self.DX[i]
                        AP = -self.DY[j] / self.DX1[i] - self.DY[j] / self.DX1[i - 1] \
                             - self.DX[i] / self.DY1[j] - self.DX[i] / self.DY1[j - 1]
                        AE = self.DY[j] / self.DX1[i]
                        AW = self.DY[j] / self.DX1[i - 1]
                        AN = self.DX[i] / self.DY1[j]
                        AS = self.DX[i] / self.DY1[j - 1]

                        DP[i,j] = -AP * self.P[i,j] \
                                   - AE * self.P[i + 1,j] - AW * self.P[i - 1,j] \
                                   - AN * self.P[i,j + 1] - AS * self.P[i,j - 1] \
                                   + DD / self.DT
                        DP[i,j] = DP[i,j] / AP
                        self.P[i,j] += self.OMEGA * DP[i,j]

                        if abs(DP[i,j]) > DMAX:
                            DMAX = abs(DP[i,j])
                            II = i
                            JJ = j

                self.Load_Pressure_Boundary(N, M)
                if (DMAX < TOL):
                    break

            self.total_fx = 0.0
            for i in range(2, N + 1):
                for j in range(2, M + 1):
                    u1 = self.U[i, j] - self.DT * (self.P[i+1, j] - self.P[i, j]) / self.DX1[i]
                    eta_avg = 0.5 * (self.ETA[i+1, j] + self.ETA[i, j])
                    u2 = (eta_avg * self.USOLID) + (1.0 - eta_avg) * u1
                    fx_local = (u2 - u1) / self.DT
                    self.total_fx += fx_local * (self.DX[i] * self.DY[j])
                    self.U[i, j] = u2
                    
            
            self.total_fy = 0.0
            for i in range(2, N + 1):
                for j in range(2, M + 1):
                    v1 = self.V[i, j] - self.DT * (self.P[i, j + 1] - self.P[i, j]) / self.DY1[j]
                    eta_avg = 0.5 * (self.ETA[i, j + 1] + self.ETA[i, j])
                    v2 = (eta_avg * self.VSOLID) + (1.0 - eta_avg) * v1
                    fy_local = (v2 - v1) / self.DT
                    self.total_fy += fy_local * (self.DX[i] * self.DY[j])
                    self.V[i, j] = v2

            self.Load_Vel_Boundary(N, M)

            c_drag = -2.0 * self.total_fx
            c_lift = -2.0 * self.total_fy

            if TIME >= 0.1:
                with open("CD_Time.dat", "a") as f:
                    line = f"{TIME:.6f}, {c_drag:.6f}, {c_lift:.6f}\n"
                    f.write(line)

            TEMP = 0.
            TS = 0.
            for i in range(1, N + 2):
                for j in range(1, M + 2):
                    UTEMP = abs(self.U[i,j] - UN1[i,j])
                    VTEMP = abs(self.V[i,j] - VN1[i,j])
                    TS += np.square(UTEMP) + np.square(VTEMP)

                    if UTEMP > VTEMP:
                        if UTEMP > TEMP:
                            TEMP = UTEMP
                    elif (VTEMP > TEMP):
                        TEMP = VTEMP

            UN1[1:N+2, 1:M+2] = np.copy(self.U[1:N+2, 1:M+2])
            VN1[1:N+2, 1:M+2] = np.copy(self.V[1:N+2, 1:M+2])
            TS = np.sqrt(TS / 2. / (N + 1) / (M + 1))   #total data is the same

            print('UV-P ITERATION NUMBER =' + str(PPPP))
            print('DMAX= ' + str(DMAX))
            print('THE MAX. VARIATION=' + str(TEMP) + ' ,SQRT OF VARIATION=' + str(TS))

            if TITE % self.FT == 0:
                File_Holder = open('flow.dat', "w+")
                File_Holder.writelines(str(TITE)+" "+str(TIME)+" "+str(PPPP)+" "+str(TEMP)+" "+str(TS) +"\n")
                File_Holder.close()

            Name_Digits = 5
            if TITE % self.OT == 0:
                File_Name = "CYL_"
                Log10_Value = int(np.floor(np.log10(TITE)))
                for i in range(Name_Digits-Log10_Value-1):
                    File_Name = File_Name + "0"
                File_Name = File_Name + str(TITE) + ".TEC"

                ST = np.zeros((N + 3, M + 3))
                VORT = np.zeros((N + 3, M + 3))

                for i in range(2, N + 1):
                    for j in range(2, M + 1):
                        ST[i,j] = ST[i,j-1] + (self.Y[j+1]-self.Y[j]) * self.U[i,j]
                        VORT[i,j] = -(self.U[i-1,j] - self.U[i-1,j-1])/(0.5 * (self.Y[j+1] - self.Y[j-1])) \
                                     +(self.V[i,j-1] - self.V[i-1,j-1])/(0.5 * (self.X[i+1] - self.X[i-1]))

                File_Holder = open(File_Name, "w+")
                File_Holder.writelines('TITLE="FLOW PAST A CYLINDER"\n')
                File_Holder.writelines('VARIABLES=X,Y,ETA,U,V,P,STREAM,VORTICITY\n')
                File_Holder.writelines('ZONE T="FLOW", I='+ str(N) + ' , J='+ str(M) + ' F=POINT\n')
                for j in range(1, M+1):
                    for i in range(1, N+1):
                        x_Middle = (self.X[i] + self.X[i+1])/2.
                        y_Middle = (self.Y[j] + self.Y[j+1])/2.
                        U_Middle = (self.U[i,j] + self.U[i-1,j])/2.
                        V_Middle = (self.V[i,j] + self.V[i,j-1])/2.
                        File_Holder.writelines(str(x_Middle)+ " "+str(y_Middle)+" "+str(self.ETA[i,j])+" "\
                                               +str(U_Middle)+" "+str(V_Middle)+" "+str(self.P[i,j])+" " \
                                               +str(ST[i,j])+" "+str(VORT[i,j])+"\n")
                File_Holder.close()

            REFILE = 'RERUN.DAT'
            File_Holder = open(REFILE, "w+")
            File_Holder.writelines(str(TIME) + "\n")
            File_Holder.writelines(str(TITE) + "\n")
            for i in range(1, N + 2):
                for j in range(1, M+2):
                    File_Holder.writelines(str(self.U[i,j])+" "+str(self.V[i,j])+" "+str(self.P[i,j])+"\n")
            for i in range(1, N + 2):
                for j in range(1, M+2):
                    File_Holder.writelines(str(FUUN1[i,j])+" "+str(FUUN2[i,j])+" "+str(FVVN1[i,j])+" "+str(FVVN2[i,j])+"\n")
            File_Holder.close()





# Main Function
MC = Main_Class(N, M)
t1 = time()
MC.Load_Input()
MC.Load_Vel_Boundary(N, M)
MC.VOS(N,M)
MC.Solver(N, M)
t2 = time()
print("Time taken by code was {:.10f}" .format(t2 - t1) + " seconds")
File = open('CLOCK.dat', "w+")
File.writelines('Time taken by code was {:.10f}' .format(t2 - t1) + ' seconds\n')
File.close()
print("The program (Solver) has run sucessfully (Pass)")
