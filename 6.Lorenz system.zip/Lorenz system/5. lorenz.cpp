#include <iostream>
#include <fstream>
#include <iomanip>      // std::setprecision
#include <cmath>

using namespace std;

int main()
{
    const int m = 1000;
    double dt = 0.01;
    double sigma = 10.0;
    double beta = 8.0 / 3.0;
    double rho = 28.0;
    double time = 0.0;
    double x[m], y[m], z[m];

    x[0] = 10.0;
    y[0] = 10.0;
    z[0] = 10.0;

    ofstream file("lorzen.dat");

    for (int i = 1; i < m; i++)
    {
        time = time + dt;
        x[i] = x[i - 1] + dt * sigma * (y[i - 1] - x[i - 1]);
        y[i] = y[i - 1] + dt * (x[i - 1] * (rho - z[i - 1]) - y[i - 1]);
        z[i] = z[i - 1] + dt * (x[i - 1] * y[i - 1] - beta * z[i - 1]);

        file << setprecision(15) << time << " " << setprecision(15) << x[i] << " " << setprecision(15) << y[i] << " " << setprecision(15) << z[i] << endl;
    }

    file.close();
    return 0;
}
