

# Main Parameter
m = 1000
dt = 0.01
sigma = 10.0
beta = 8./3.
rho = 28.0
time = 0.0

# Declare
x = [0. for i in range(m+1)]
y = [0. for i in range(m+1)]
z = [0. for i in range(m+1)]

# Set Initial Value
x[1] = 10.
y[1] = 10.
z[1] = 10.

# Main Loop
FileHolder = open("Lorenz.dat", "w+")
for i in range(2, m+1):
    time += dt
    x[i]=x[i-1] + dt * sigma * (y[i-1] - x[i-1])
    y[i]=y[i-1] + dt * (x[i-1] * (rho - z[i-1]) - y[i-1])
    z[i]=z[i-1] + dt * (x[i-1] * y[i-1] - beta * z[i-1])
    FileHolder.writelines(str(x[i]) + "\t" + str(y[i]) + "\t" + str(z[i]) + "\n")
FileHolder.close()