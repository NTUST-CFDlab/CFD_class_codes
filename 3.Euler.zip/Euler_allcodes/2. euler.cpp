#include <iostream>
#include <fstream>
#include <iomanip>      // std::setprecision
#include <cmath>

using namespace std;

const int m = 100;
const double dt = 0.0001;

int main()
{
    int i;
    double time, discrepancy, xa;
    double x = 5.7;
    time = 0.0;
    ofstream outFile("euler.dat");
    for (i = 2; i <= m; i++) {
        time = time + dt;
        x = x + dt * (3.0 * x);
        xa = 5.7 * exp(3.0 * time);
        outFile << time << " " << x << " " << xa << endl;
    }
    discrepancy = x - xa;
    cout << setprecision(15) << time << " " << setprecision(15) << x << " " << setprecision(15) << xa << " " << setprecision(15) << discrepancy << endl;
    outFile.close();
    return 0;
}
