# ---------------------------------------
# This program is to calculate the Euler equation
# ---------------------------------------

# Import
import math

# Main Parameter
m = 100
dt = 0.0001
time = 0.0
x = 5.7

# Main Loop
FileHolder = open("euler.dat", "w+")
for i in range(2, m+1):
    time += dt
    x = x + dt * (3. * x)
    xa = 5.7 * math.exp(3. * time)
    FileHolder.writelines(str(time) + "\t" + str(x) + "\t" + str(xa) + "\n")
FileHolder.close()

discrepancy = x - xa
print(time, x, xa, discrepancy)
