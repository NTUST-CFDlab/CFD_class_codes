program euler
implicit none
integer, parameter :: m = 100
integer :: i
double precision, parameter :: dt = 0.0001
double precision :: time, discrepancy, xa
double precision :: x


x=5.7


time=0.0
open(unit=11, file='euler.dat')

do i = 1, m
   time=time+dt
   x=x+dt*(3.*x)
   xa=5.7*dexp(3.*time)
  
   
   write(11,*)time, x, xa
end do

discrepancy=x-xa
write(*,*)time,x,xa,discrepancy
close(11)
end program euler