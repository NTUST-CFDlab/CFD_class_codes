#--------------------------------------------
# PROGRAM:  Burger2d
# PURPOSE:  To solve Burger's 2D equation
# Warning:	It may take a while to run using the default settings
#--------------------------------------------

# Import
import numpy as np
import matplotlib.pyplot as plt

# Parameters
m = 100				# Spatial division
timestep = 10		# Total time step
Re = 10.			# Reynolds number
dt = 0.000001		# Time step size
time = 0.			# Current time

Domain_x_Min = 0.
Domain_x_Max = 1.
Domain_y_Min = 0.
Domain_y_Max = 1.

# Mesh
dx = (Domain_x_Max - Domain_x_Min)/m
dy = (Domain_y_Max - Domain_y_Min)/m
Total_Cells = np.square(m+1)

# Check CFL
dx2 = np.square(dx)
dy2 = np.square(dy)
if (dt > Re * dx2 * dy2 / (2. * (dx2 + dy2))):
	print("dt is not small enough.")
	print("Maximum dt is " + str(Re * dx2 * dy2 / (2. * (dx2 + dy2))))
	exit()

# Set coordinate and initial condition
xspace = np.linspace(Domain_x_Min, Domain_x_Max, m+1)
yspace = np.linspace(Domain_y_Min, Domain_y_Max, m+1)
x, y = np.meshgrid(xspace, yspace)
x = np.transpose(x)
y = np.transpose(y)
u = x + y
v = x - y

# Main Loop
File = open('burger2d.dat', "w+")
fdx2 = 1./dx2
fdy2 = 1./dy2
i, j = np.arange(1, m), np.arange(1, m)

for k in range(timestep):
	time += dt
	ftime_constant = 1. / (1. - 2. * np.square(time))

	diffx = (u[i - 1, j] - 2. * u[i, j] + u[i + 1, j]) * fdx2 + (u[i, j - 1] - 2. * u[i, j] + u[i, j + 1]) * fdy2
	diffy = (v[i - 1, j] - 2. * v[i, j] + v[i + 1, j]) * fdx2 + (v[i, j - 1] - 2. * v[i, j] + v[i, j + 1]) * fdy2

	ue = np.where(u[i, j] > 0, u[i, j], u[i + 1, j])
	uw = np.where(u[i, j] > 0, u[i - 1, j], u[i, j])
	ve = np.where(u[i, j] > 0, v[i, j], v[i + 1, j])
	vw = np.where(u[i, j] > 0, v[i - 1, j], v[i, j])
	vn = np.where(v[i, j] > 0, v[i, j], v[i, j + 1])
	vs = np.where(v[i, j] > 0, v[i, j - 1], v[i, j])
	un = np.where(v[i, j] > 0, u[i, j], u[i, j + 1])
	us = np.where(v[i, j] > 0, u[i, j - 1], u[i, j])

	convecx = (ue * ue - uw * uw) / dx + (vn * un - vs * us) / dy
	convecy = (ue * ve - uw * vw) / dx + (vn * vn - vs * vs) / dy
	u[i, j] = u[i, j] + dt * (-convecx + diffx / Re)
	v[i, j] = v[i, j] + dt * (-convecy + diffy / Re)

	# Boundary Conditions
	u[:, 0] = (xspace + yspace[0] - 2. * xspace * time) * ftime_constant
	u[:, m] = (xspace + yspace[m] - 2. * xspace * time) * ftime_constant
	v[:, 0] = (xspace - yspace[0] - 2. * yspace[0] * time) * ftime_constant
	v[:, m] = (xspace - yspace[m] - 2. * yspace[m] * time) * ftime_constant

	u[0, :] = (xspace[0] + yspace - 2. * xspace[0] * time) * ftime_constant
	u[m, :] = (xspace[m] + yspace - 2. * xspace[m] * time) * ftime_constant
	v[0, :] = (xspace[0] - yspace - 2. * yspace * time) * ftime_constant
	v[m, :] = (xspace[m] - yspace - 2. * yspace * time) * ftime_constant

	# Error Calculation
	u_analytic = (x + y - 2 * x * time)* ftime_constant
	v_analytic = (x - y - 2 * y * time)* ftime_constant
	Vel_Magnitude = np.sqrt(np.square(u) + np.square(v))
	Error_u_Square = np.square(u - u_analytic)
	Error_v_Square = np.square(v - v_analytic)
	Total_u_error = np.sum(Error_u_Square)
	Total_v_error = np.sum(Error_v_Square)
	L2_norm_u = np.sqrt(Total_u_error/Total_Cells)
	L2_norm_v = np.sqrt(Total_v_error/Total_Cells)

	# Write Results
	for ii in range(m+1):
		for jj in range(m+1):
			Total_Line = str(x[ii][jj]) + "\t" + str(y[ii][jj]) + "\t" \
						 + str(u_analytic[ii][jj]) + "\t" + str(u[ii][jj]) + "\t" \
						 + str(v_analytic[ii][jj]) + "\t" + str(v[ii][jj]) + "\t" \
						 + str(Vel_Magnitude[ii][jj])
			File.writelines(Total_Line +"\n")
	print("Time: " + str(time))
	print("L2 norm u: "+str(L2_norm_u))
	print("L2 norm v: "+str(L2_norm_v))

File.close()

# Plot Last results
# plt.figure()
fig, ax = plt.subplots(1, 2, figsize=(12, 4))
#c1 = ax[0].contour(x, y, u, cmap='rainbow')
c1 = ax[0].pcolormesh(x, y, u, cmap='rainbow')
ax[0].set_title('u')
ax[0].set_xlabel('x')
ax[0].set_ylabel('y')
cbar1 = fig.colorbar(c1, ax=ax[0], pad = 0.05, aspect = 10)
cbar1.mappable.set_clim(np.min(u), np.max(u))

#c2 = ax[1].contour(x, y, v, cmap='rainbow')
c2 = ax[1].pcolormesh(x, y, v, cmap='rainbow')
ax[1].set_title('v')
ax[1].set_xlabel('x')
ax[1].set_ylabel('y')
cbar2 = fig.colorbar(c2, ax=ax[1], pad = 0.05, aspect = 10)
cbar2.mappable.set_clim(np.min(v), np.max(v))

#plt.show()
plt.savefig("PlotB2D.png")