//****************************************************************************
//
// PROGRAM: burger2d
//
//  PURPOSE:  To solve Burger's 2D equation
//
//****************************************************************************

#include <stdio.h>
#include <math.h>

#define m 100
#define timestep 50000

int main() {
    int i, j, k;
    double Re, dt, dx, dy, time;
    double diffx, diffy, convecx, convecy;
    double u[m+1][m+1], v[m+1][m+1], x[m+1], y[m+1];
    double ua[m+1][m+1], va[m+1][m+1], vel[m+1][m+1];
    double erru, errv, L2normu, L2normv;
    double ue, uw, ve, vw, un, us, vn, vs;
    
    FILE *fptr;
    fptr = fopen("burger2d.dat", "w");
	
    Re = 10.0;
    dt = 0.000001;
    time = 0.0;
    dx = 1.0/(1.0*m);
    dy = 1.0/(1.0*m);
  
    if (dt > (Re*dx*dx * dy*dy)/(2.0*(dx*dx + dy*dy))) {
        printf("Dt is not small enough.\n");
        printf("Maximum Dt is %f\n", (Re*dx*dx * dy*dy)/(2.0*(dx*dx + dy*dy)));
        return 0;
    }
   
    // Initial condition
    for (i = 0; i <= m; i++) {
        x[i] = i*dx;
        y[i] = i*dy;
    }

    for (i = 0; i <= m; i++) {
        for (j = 0; j <= m; j++) {
            u[i][j] = x[i] + y[j];
            v[i][j] = x[i] - y[j];
        }
    }

	for (k = 1; k <= timestep; k++) {
		time = time + dt;
		
		for (i = 1; i < m; i++) {
			for (j = 1; j < m; j++) {
				// Diffusion term
				diffx = (u[i-1][j] - 2.0*u[i][j] + u[i+1][j])/(dx*dx) + (u[i][j-1] - 2.0*u[i][j] + u[i][j+1])/(dy*dy);
				diffy = (v[i-1][j] - 2.0*v[i][j] + v[i+1][j])/(dx*dx) + (v[i][j-1] - 2.0*v[i][j] + v[i][j+1])/(dy*dy);
            
				// Convection term using upwind scheme
				if (u[i][j] > 0.0) {
					ue = u[i][j];
					uw = u[i-1][j];
					ve = v[i][j];
					vw = v[i-1][j];
				} else {
					ue = u[i+1][j];
					uw = u[i][j];
					ve = v[i+1][j];
					vw = v[i][j];
				}
            
				if (v[i][j] > 0.0) {
					vn = v[i][j];
					vs = v[i][j-1];
					un = u[i][j];
					us = u[i][j-1];
				} else {
					vn = v[i][j+1];
					vs = v[i][j];
					un = u[i][j+1];
					us = u[i][j];
				}
            
				convecx = (ue*ue - uw*uw)/dx + (vn*un - vs*us)/dy;
				convecy = (ue*ve - uw*vw)/dx + (vn*vn - vs*vs)/dy;
            
				u[i][j] = u[i][j] + dt*(-convecx + diffx/Re);
				v[i][j] = v[i][j] + dt*(-convecy + diffy/Re);
			}
		}
	
		for (int i = 0; i <= m; i++) {
			for (int j = 0; j <= m; j++) {
				u[i][0] = (x[i] + y[0] - 2.0 * x[i] * time) / (1.0 - 2.0 * time * time);
				u[i][m] = (x[i] + y[m] - 2.0 * x[i] * time) / (1.0 - 2.0 * time * time);
				v[i][0] = (x[i] - y[0] - 2.0 * y[0] * time) / (1.0 - 2.0 * time * time);
				v[i][m] = (x[i] - y[m] - 2.0 * y[m] * time) / (1.0 - 2.0 * time * time);
				u[0][j] = (x[0] + y[j] - 2.0 * x[0] * time) / (1.0 - 2.0 * time * time);
				u[m][j] = (x[m] + y[j] - 2.0 * x[m] * time) / (1.0 - 2.0 * time * time);
				v[0][j] = (x[0] - y[j] - 2.0 * y[j] * time) / (1.0 - 2.0 * time * time);
				v[m][j] = (x[m] - y[j] - 2.0 * y[j] * time) / (1.0 - 2.0 * time * time);
			}
		}
	}
	
	erru = 0.0;
	errv = 0.0;

	for (int i = 0; i <= m; i++) {
		for (int j = 0; j <= m; j++) {
			ua[i][j] = (x[i] + y[j] - 2.0*x[i]*time)/(1.0 - 2.0*time*time);
			va[i][j] = (x[i] - y[j] - 2.0*y[j]*time)/(1.0 - 2.0*time*time);
			vel[i][j] = sqrt(u[i][j] * u[i][j] + v[i][j] * v[i][j]);
			erru = erru + pow((u[i][j] - ua[i][j]), 2);
			errv = errv + pow((v[i][j] - va[i][j]), 2);
			fprintf(fptr, "%10.3f %10.3f %50.40f %50.40f %50.40f %50.40f %10.3f\n", x[i], y[j], ua[i][j], u[i][j], va[i][j], v[i][j], vel[i][j]);
		}
	}
	
	L2normu = sqrt(erru/((m + 1.0)*(m + 1.0)));
	L2normv = sqrt(errv/((m + 1.0)*(m + 1.0)));
	printf("%10.3f %10.3f\n", L2normu, L2normv);

	fclose(fptr);

	return 0;
}
    
