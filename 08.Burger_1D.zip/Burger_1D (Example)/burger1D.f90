program burger
implicit none  
integer, parameter :: m = 100, timestep = 10000
integer :: i, j
double precision :: alpha, pi, dt, dx, time, diffusion, convec, ue, uw
double precision :: u(0:m), x(0:m), u_new(0:m)

alpha = 0.1
pi = dacos(-1.d0)
dt = 0.0001
time = 0.d0
dx = 2.d0/(1.0*m)
write(*,*)pi

if (dt .gt. dx**2/(2.0*alpha)) then
    write(*,*)'Dt is not small enough.'
end if

open(unit=11, file='burger.dat')
do i = 0, m
   x(i) = -1.0+2.*i/(1.*m)
   u(i) = -dsin(pi*x(i))
end do

do j = 1, timestep
   time = time + dt
   do i = 1, m-1

! upwind scheme      
      if ( u(i) .gt. 0.0) then
         ue = u(i)
         uw = u(i-1)
      else
         ue = u(i+1)
         uw = u(i)
      end if    
      convec = (ue*ue-uw*uw)/dx
      diffusion = alpha*(u(i-1)-2.*u(i)+u(i+1))/dx**2
	  
      u_new(i) = u(i) + dt*(-convec + diffusion)	! u(n+1)

   end do  
   u = u_new										! u(n) for the next timestep
end do

do i = 0, m
   write(11,*) x(i), u(i)
end do   

close(11)
end program burger 
