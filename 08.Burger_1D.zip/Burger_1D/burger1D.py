import math

m = 100
timestep = 10000
alpha = 0.1
pi = math.acos(-1.0)
dt = 0.0001
time = 0.0
dx = 2.0 / (1.0 * m)

print(pi)

if dt > dx**2 / (2.0 * alpha):
    print('Dt is not small enough.')

file = open('burger.dat', 'w')

x = [-1.0 + 2.0 * i / (1.0 * m) for i in range(m+1)]
u = [-math.sin(pi * x_i) for x_i in x]
u_new = u.copy()

for j in range(1, timestep + 1):
    time += dt
    for i in range(1, m):

        if u[i] > 0.0:
            ue = u[i]
            uw = u[i-1]
        else:
            ue = u[i+1]
            uw = u[i]

        convec = (ue**2 - uw**2) / dx
        diffusion = alpha * (u[i-1] - 2.0 * u[i] + u[i+1]) / dx**2

        u_new[i] += dt * (-convec + diffusion)

    for i in range(1, m):
        u[i] = u_new[i]

for i in range(m+1):
    print(x[i], u[i], file=file)

file.close()
