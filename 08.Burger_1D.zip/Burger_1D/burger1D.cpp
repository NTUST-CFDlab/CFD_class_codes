#include <iostream>
#include <fstream>
#include <cmath>

int main() {
    const int m = 100;
    const int timestep = 10000;
    double alpha, pi, dt, dx, time, diffusion, convec, ue, uw;
    double u[m+1], x[m+1], u_new[m+1];

    alpha = 0.1;
    pi = acos(-1.0);
    dt = 0.0001;
    time = 0.0;
    dx = 2.0 / (1.0 * m);
    std::cout << pi << std::endl;

    if (dt > dx*dx / (2.0 * alpha)) {
        std::cout << "Dt is not small enough." << std::endl;
    }

    std::ofstream file("burger.dat");
    for (int i = 0; i <= m; i++) {
        x[i] = -1.0 + 2.0 * i / (1.0 * m);
        u[i] = -sin(pi * x[i]);
    }

    for (int j = 1; j <= timestep; j++) {
        time += dt;
        for (int i = 1; i < m; i++) {
            if (u[i] > 0.0) {
                ue = u[i];
                uw = u[i-1];
            } else {
                ue = u[i+1];
                uw = u[i];
            }
            convec = (ue * ue - uw * uw) / dx;
            diffusion = alpha * (u[i-1] - 2.0 * u[i] + u[i+1]) / (dx * dx);

            u_new[i] = u[i] + dt * (-convec + diffusion);
        }
		
		for (int i = 1; i < m; i++) {
			u[i] = u_new[i];
		}
    }

    for (int i = 0; i <= m; i++) {
        file << x[i] << " " << u[i] << std::endl;
    }

    file.close();

    return 0;
}
