!  burger2d.f90 !

!****************************************************************************
!
!  PROGRAM: burger1d
!
!  PURPOSE:  To solve Burger's 1D equation
!
!****************************************************************************

    PROGRAM burger1d
    implicit none  
    integer, parameter :: m = 100, timestep = 10000	
    integer :: i, iter
    double precision :: dt, dx, time
    double precision :: u(-1:m+1), v(-1:m+1), x(-1:m+1)
    double precision :: u_new(0:m), v_new(0:m)
    double precision :: ua(0:m), va(0:m), vel(0:m)
	double precision :: erru, errv, L2normu, L2normv
	double precision :: uux,vvx,t1,t2
	double precision :: ue,uw,ue1,uw1,ve1,vw1
    double precision , parameter :: PI = 4.d0*ATAN(1.d0)

!	Exact solution's coefficients
    double precision, parameter  :: eta   = -2.d0
    double precision, parameter  :: alpha = 1.d0	
    double precision, parameter  :: beta  = 1.d0
    double precision :: A = 0.5d0*0.05d0*((4.d0*alpha*beta-1.d0)/(2.d0*alpha-1.d0))
	
    
    open(unit=11, file='burger1d_final.dat')
    open(unit=21, file='burger1d_l2norm.dat')
    ! open(unit=31, file='dvdx.dat')

	
    dt = 1.d-4
    time = 0.d0
    dx = 2.d0*PI/(1.d0*m)


	write(*,2) 'dx = ',dx,'		dt = ',dt
2	format(1x,2(A,E15.7,1x))
  
    if (dt .gt. dx**2/2.d0) then
    write(*,*)'Dt is not small enough.'
	!dtmax = (Re*dx**2 * dy**2)/(2.*(dx**2 + dy**2))
	write(*,*)'Maximum Dt is', dx**2/2.d0
    stop
    end if
   

	call cpu_time(t1)

    do i = -1, m+1
        x(i) = i*dx-PI
    end do

    !-----Initial condition-----------------------------------
    do i = -1, m+1
        u(i) = func_u(x(i),0.d0)
        v(i) = func_v(x(i),0.d0)
    end do
	!-----End of initial condition----------------------------

   !-----Boundary condition-----------------------------------
        u(0) = func_u(x(0),time)
        u(m) = func_u(x(m),time)
        v(0) = func_v(x(0),time)
        v(m) = func_v(x(m),time)
        u(-1)  = func_u(x(-1),time)
        u(m+1) = func_u(x(m+1),time)
        v(-1)  = func_v(x(-1),time)
        v(m+1) = func_v(x(m+1),time)
   !-----End of boundary condition----------------------------
    
    do iter = 1, timestep
       time = time + dt
      
       do i = 1, m-1

            ! Convection term using QUICK scheme
			if ( u(i) .gt. 0.d0) then
				ue1 = 0.75d0 * u(i)   + 0.375d0 * u(i+1) - 0.125d0 * u(i-1)
				uw1 = 0.75d0 * u(i-1) + 0.375d0 * u(i)   - 0.125d0 * u(i-2)
			else
				ue1 = 0.75d0 * u(i+1) + 0.375d0 * u(i)   - 0.125d0 * u(i+2)
				uw1 = 0.75d0 * u(i)   + 0.375d0 * u(i-1) - 0.125d0 * u(i+1)
			endif 

			ue = 0.5d0 * (u(i+1)+u(i))
			uw = 0.5d0 * (u(i-1)+u(i))
			
			if ( ue .gt. 0.d0) then
				ve1 = 0.75d0 * v(i)   + 0.375d0 * v(i+1) - 0.125d0 * v(i-1)
			else
				ve1 = 0.75d0 * v(i+1) + 0.375d0 * v(i)   - 0.125d0 * v(i+2)
			endif 
			if ( uw .gt. 0.d0) then
				vw1 = 0.75d0 * v(i-1) + 0.375d0 * v(i)   - 0.125d0 * v(i-2)
			else
				vw1 = 0.75d0 * v(i)   + 0.375d0 * v(i-1) - 0.125d0 * v(i+1)
			endif 	
	   
		   u_new(i) = u(i) + dt*(((u(i+1)-u(i))/dx - (u(i)-u(i-1))/dx)/dx   &
						- eta*(u(i)*ue1 - u(i)*uw1)/dx &
						- alpha*(ue*ve1 - uw*vw1)/dx)

		   v_new(i) = v(i) + dt*(((v(i+1)-v(i))/dx - (v(i)-v(i-1))/dx)/dx   &
						- eta*(v(i)*ve1 - v(i)*vw1)/dx &
						- beta*(ue*ve1 - uw*vw1)/dx)
	   end do



       do i = 1, m-1
			u(i) = u_new(i)		
			v(i) = v_new(i)	
       end do	

   !-----Boundary condition-----------------------------------
        u(0) = func_u(x(0),time)
        u(m) = func_u(x(m),time)
        v(0) = func_v(x(0),time)
        v(m) = func_v(x(m),time)
        u(-1)  = func_u(x(-1),time)
        u(m+1) = func_u(x(m+1),time)
        v(-1)  = func_v(x(-1),time)
        v(m+1) = func_v(x(m+1),time)
   !-----End of boundary condition----------------------------
   
	  
	if(mod(iter,100) == 0) then 
		erru = 0.d0
		errv = 0.d0
		do i = 0, m
			  ua(i) = func_u(x(i),time)
			  va(i) = func_v(x(i),time)
			  
			  erru = erru + (u(i)-ua(i))**2
			  errv = errv + (v(i)-va(i))**2
		end do
		L2normu = sqrt(erru/((m+1)*1.d0))
		L2normv = sqrt(errv/((m+1)*1.d0))
		write(21,3) time,L2normu,L2normv
		write(*,*) time,L2normu,L2normv
    3	format(F9.5,1x, 2(E20.10,1x))
	endif
	   
    end do

	
	erru = 0.d0
	errv = 0.d0
    do i = 0, m
          ua(i) = func_u(x(i),time)
          va(i) = func_v(x(i),time)
		  erru = erru + (u(i)-ua(i))**2
		  errv = errv + (v(i)-va(i))**2
          write(11,4) x(i), ua(i), u(i), va(i), v(i)
    4	  format(1(E10.3,1x), 4(E15.7,1x))
    end do
	L2normu = sqrt(erru/((m+1)*1.d0))
	L2normv = sqrt(errv/((m+1)*1.d0))
	write(*,*) 'L2norm u = ',L2normu,'	L2norm v = ',L2normv
	
	
	call cpu_time(t2)
	write(*,*) 'Total computational time = ',(t2-t1)/60.d0,' minutes'
    
    close(11)
	close(21)
	! close(31)

	CONTAINS


!---Exact solution 01 ; eta = -2.d0 ; alpha = beta = 1.d0 ; [-PI,PI]------------	

	FUNCTION func_u(xf,timef) result(u_Val)
	IMPLICIT NONE
	double precision , intent(in) :: xf,timef
	double precision :: u_Val
	
	u_Val = exp(-timef) * sin(xf)

	END FUNCTION func_u
	
	
	FUNCTION func_v(xf,timef) result(v_Val)
	IMPLICIT NONE
	double precision , intent(in) :: xf,timef
	double precision :: v_Val
	
	v_Val = exp(-timef) * sin(xf)
	
	END FUNCTION func_v
!-------------------------------------------------------------------------------
	
!---Exact solution 02 ; eta = 2.d0 ; alpha = beta = any ; [-10,10]--------------	

	! FUNCTION func_u(xf,timef) result(u_Val)
	! IMPLICIT NONE
	! double precision , intent(in) :: xf,timef
	! double precision :: u_Val
	
	! u_Val = 0.05d0*(1.d0 - tanh(A*(xf-2.d0*A*timef)))

	! END FUNCTION func_u
	
	
	! FUNCTION func_v(xf,timef) result(v_Val)
	! IMPLICIT NONE
	! double precision , intent(in) :: xf,timef
	! double precision :: v_Val
	
	! v_Val = 0.05d0*(((2.d0*beta-1.d0)/(2.d0*alpha-1.d0)) - tanh(A*(xf-2.d0*A*timef)))
	
	! END FUNCTION func_v
!-------------------------------------------------------------------------------
	
    END PROGRAM burger1d