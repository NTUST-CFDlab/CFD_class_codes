//****************************************************************************
//
//  PROGRAM: burger2d with a single velocity component (u)
//
//  PURPOSE:  To solve Burger's 2D equation
//
//****************************************************************************

#include <stdio.h>
#include <math.h>

const int m = 100, q = 100, timestep = 1000;

int main() {

    int i, j, k;
    double re, pi, dt, dx, dy, time, ue, uw, un, us;
	double diffusion, convec, l2norm;
    double x[m+1], y[q+1], u[m+1][q+1], ua[m+1][q+1];

    re = 10.0;
    pi = acos(-1.0);
    dt = 0.0001;
    time = 0.0;
    dx = 2.0/(1.0*m);
    dy = 2.0/(1.0*q);

    if (dt > re*dx*dx/2.0) {
        printf("Dt is not small enough.\n");
        return 0;
    }

    FILE *fptr;
    fptr = fopen("burger2d.dat", "w");

    for (i = 0; i <= m; i++) {
        x[i] = -1.0 + 2.0*i/(1.0*m);
    }
    for (k = 0; k <= q; k++) {
        y[k] = -1.0 + 2.0*k/(1.0*q);
    }
    for (i = 0; i <= m; i++) {
        for (k = 0; k <= q; k++) {
            u[i][k] = 1.0/(1.0 + exp(re*(x[i]+y[k])/2.0));
        }
    }

    for (j = 1; j <= timestep; j++) {
        time = time + dt;
        for (i = 1; i <= m-1; i++) {
            for (k = 1; k <= q-1; k++) {
                diffusion = ((u[i-1][k] - 2.0*u[i][k] + u[i+1][k])/dx/dx
                            + (u[i][k-1] - 2.0*u[i][k] + u[i][k+1])/dy/dy)/re;
                un = (u[i][k+1] + u[i][k])/2.0;
                us = (u[i][k] + u[i][k-1])/2.0;
                // Upwind scheme
                if (u[i][k] > 0.0) {
                    ue = u[i][k];
                    uw = u[i-1][k];
                }
                else {
                    ue = u[i+1][k];
                    uw = u[i][k];
                }
                convec = (ue*ue - uw*uw)/dx + (un*un - us*us)/dy;
                u[i][k] = u[i][k] + dt*(-0.5*convec + diffusion);
            }
        }
		for (i = 0; i <= m; ++i) {
			u[i][0] = 1.0 / (1.0 + exp(re * (x[i] - time) / 2.0));
			u[i][q] = 1.0 / (1.0 + exp(re * (1.0 + x[i] - time) / 2.0));
		}
    
		for (k = 0; k <= q; ++k) {
			u[0][k] = 1.0 / (1.0 + exp(re * (y[k] - time) / 2.0));
			u[m][k] = 1.0 / (1.0 + exp(re * (1.0 + y[k] - time) / 2.0));
		}
	}

	l2norm = 0.0;
	for (int i = 0; i <= m; ++i) {
		for (int k = 0; k <= q; ++k) {
            ua[i][k] = 1.0/(1.0+ exp(re*(x[i]+y[k]-time)/2.0));
			l2norm += pow((u[i][k] - ua[i][k]), 2);
			fprintf(fptr, "%10.3f %10.3f %50.40f\n", x[i], y[k], u[i][k]);
		}
	}

	l2norm = sqrt(l2norm / ((m + 1) * (q + 1) * 1.0));
	printf("%f\n", l2norm);
				
	fclose(fptr);
	return 0;
}