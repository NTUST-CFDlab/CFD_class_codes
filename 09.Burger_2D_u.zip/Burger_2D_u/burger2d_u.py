#****************************************************************************
#
#  PROGRAM: burger2d with a single velocity component (u)
#
#  PURPOSE:  To solve Burger's 2D equation
#
#****************************************************************************

# Import
import math

# Parameters
m = 100             # Spatial division
q = 100
timestep = 1000     # Total time step
Re = 10.            # Reynolds number
dt = 0.0001         # Time step size
time = 0.           # Current time

dx = 2./m
dy = 2./q

# Declare Array
x = [0. for i in range(m+1)]
y = [0. for k in range(q+1)]
u = [[0. for k in range(q+1)] for i in range(m+1)]
ua = [[0. for k in range(q+1)] for i in range(m+1)]
u_new = u.copy()

# Check CFL
if (dt > Re * dx**2 / 2. ):
    print("dt is not small enough.")
    exit()

# Set coordinate and initial condition
File = open('burger2d.dat', "w+")
for i in range(m+1):
    x[i] = -1. + 2. * i / m
for k in range(q+1):
    y[k] = -1. + 2. * k / q
for i in range(m+1):
    for k in range(q + 1):
        u[i][k] = 1. / (1. + math.exp(Re * (x[i] + y[k]) / 2.))


# Main Loop
for j in range(1, timestep):
    time += dt
    print("Current time ", time)
    for i in range(1, m):
        for k in range(1, q):
            diffusion = (u[i-1][k] - 2.*u[i][k] + u[i+1][k]) / dx**2 / Re + \
                        (u[i][k-1] - 2.*u[i][k] + u[i][k+1]) / dy**2 / Re

            un = (u[i][k+1] + u[i][k]) / 2.
            us = (u[i][k] + u[i][k-1]) / 2.

            # Upwind Scheme
            if (u[i][k] > 0.):
                ue = u[i][k]
                uw = u[i-1][k]
            else:
                ue = u[i+1][k]
                uw = u[i][k]

            convec = (ue * ue - uw * uw) / dx + (un * un - us * us) / dy
            u_new[i][k] = u[i][k] + dt * (-0.5 * convec + diffusion)
            ua[i][k] = 1. / (1. + math.exp(Re * (x[i] + y[k]- time) / 2.0))
    
    for i in range(1, m):
        for k in range(1, q):
            u[i][k] = u_new[i][k]

    for i in range(m+1):
        u[i][0] = 1. / (1. + math.exp(Re * (x[i] - time) / 2.0))
        u[i][q] = 1. / (1. + math.exp(Re * (x[i] + 1. - time) / 2.0))
    for k in range(q+1):
        u[0][k] = 1. / (1. + math.exp(Re * (y[k] - time) / 2.0))
        u[m][k] = 1. / (1. + math.exp(Re * (1. + y[k] - time) / 2.0))

l2norm = 0.
for i in range(m+1):
    for k in range(q+1):
        File.writelines(str(x[i]) + "\t" + str(y[k]) + "\t" + str(u[i][k]) + "\n")
        l2norm += (u[i][k] - ua[i][k]) ** 2
print(l2norm / m / q)
File.close()