#include <iostream>
#include <fstream>
#include <iomanip>      // std::setprecision
#include <cmath>

using namespace std;

const int m = 10000;

int main()
{
    int i;
    double dx, fa, discrepancy, sum, error;
    double x[m+1], func[m+1], dfdx[m];
    dx = 2.0 / m;
    x[0] = -1.0;
    func[0] = 3.0 * x[0] * x[0] * x[0] + 2.0 * x[0] * x[0] + 6.0 * x[0] + 20.0;
    ofstream outFile("001.dat");
    for (i = 1; i <= m; i++) {
        x[i] = x[i-1] + dx;
        func[i] = 3.0 * x[i] * x[i] * x[i] + 2.0 * x[i] * x[i] + 6.0 * x[i] + 20.0;
        // outFile << x[i] << " " << func[i] << endl;
    }
    sum = 0.0;
    for (i = 1; i < m; i++) {
        fa = 9.0 * x[i] * x[i] + 4.0 * x[i] + 6.0;
        dfdx[i] = (func[i+1] - func[i-1]) / (2.0 * dx);
        discrepancy = dfdx[i] - fa;
        outFile << setprecision(15) << x[i] << " " << setprecision(15) << func[i] << " " << setprecision(15) << discrepancy << endl;
        sum = sum + pow(discrepancy, 2.0);
    }
    outFile.close();
    error = sqrt(sum) / m;
    cout << m << " " << error << endl;
    return 0;
}
