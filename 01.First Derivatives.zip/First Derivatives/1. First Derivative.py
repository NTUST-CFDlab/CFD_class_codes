# ---------------------------------------
# This program is to calculate the first order derivative
# ---------------------------------------

# Import
import math

# Main Parameter
m = 10000
dx = 2./m

# Declare Array
x = [0 for i in range(m+1)]
func = [0 for i in range(m+1)]
dfdx = [0 for i in range(m+1)]

# Calculate initial valye
x[0] = -1.
func[0] = 3.*x[0]*x[0]*x[0] + 2.*x[0]*x[0] + 6.*x[0]+ 20.
FileHolder = open("001.dat", "w+")
FileHolder.writelines(str(x[0]) + "\t" + str(func[0]) + "\n")

# Main loop
for i in range(1, m+1):
    x[i] = x[i-1] + dx
    func[i] = 3.*x[i]*x[i]*x[i] + 2.*x[i]*x[i] + 6.*x[i] + 20.
    FileHolder.writelines(str(x[i]) + "\t" + str(func[i]) + "\n")
    
# Error
sum = 0.
for i in range(1, m):
    fa = 9.*x[i]*x[i] + 4.*x[i] + 6.
    dfdx[i] = (func[i+1] - func[i-1])/2./dx
    discrepancy = dfdx[i] - fa
    sum = sum + discrepancy**2
    FileHolder.writelines(str(x[i]) + "\t" + str(func[i]) + "\t" + str(discrepancy) +"\n")

FileHolder.close()

error = math.sqrt(sum)/m
print(m, error)
