#include <iostream>
#include <fstream>
#include <iomanip>      // std::setprecision
#include <cmath>
using namespace std;

const int m = 100, timestep = 10000;
const double dt = 0.0001;

int main() {
    int i, j;
    double time, length, discrepancy, alpha, dx;
    double x[m+1], temp[m+1], tempold[m+1];

    length = 1.0;
    dx = length/m;
    for (i = 0; i <= m; ++i) {
        x[i] = length*i/(1.*m);
        temp[i] = 10.0;
    }

    alpha = 0.1;
    time = 0.0;
    ofstream outFile("conduction.dat");

    temp[0] = 0.0;
    temp[m] = 20.0;
    for (j = 1; j <= timestep; ++j) {
        time += dt;
        for (i = 0; i <= m; ++i) {
            tempold[i] = temp[i];
        }
        for (i = 1; i < m; ++i) {
            temp[i] += dt*alpha*(tempold[i+1]-2.*tempold[i]+tempold[i-1])/dx/dx;
        }
    }

    for (i = 0; i <= m; ++i) {
        outFile << setprecision(15) << x[i] << " " << setprecision(15) << temp[i] << endl;
    }

    outFile.close();
    return 0;
}
