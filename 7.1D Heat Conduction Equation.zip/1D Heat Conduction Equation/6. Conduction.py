
# Import
import math

# Main Parameter
m = 100
alpha = 0.1
length = 1.0
timestep = 10000
dt = 0.0001
time = 0.0

# Declare Array
x = [0. for i in range(m+1)]
temp = [0. for i in range(m+1)]
tempold= [0. for i in range(m+1)]

# Set x & initial temperature
dx = length/m
for i in range(m+1):
    x[i] = i * dx
    temp[i] = 10.

# Set boundary condtion
temp[0] = 0.
temp[m] = 20.

# Main Loop
for j in range(1, timestep+1):
    time += dt
    for i in range(m+1):
        tempold[i] = temp[i]
    for i in range(1, m):
        temp[i] = temp[i] + dt * alpha * (tempold[i + 1] - 2. * tempold[i] + tempold[i - 1]) / (dx ** 2)

FileHolder = open("conduction.dat", "w+")
for i in range(m+1):
    FileHolder.writelines(str(x[i]) + "\t" + str(temp[i]) + "\n")
FileHolder.close()