# ---------------------------------------
# This program is to calculate using Runge Kutta (RK4) method
# ---------------------------------------

# Import
import math

# Main Parameter
m = 3000
dt = 0.0001
time = 0.0
x = 5.7

# Main Loop
FileHolder = open("rk4.dat", "w+")
for i in range(2, m+1):
    time += dt
    k1 = 3. * x
    k2 = 3. * (x + dt + k1/2.)
    k3 = 3. * (x + dt * k2/2.)
    k4 = 3. * (x + dt + k3)
    x = x + dt * (k1 + 2. * k2 + 2. * k3 + k4)/6.
    xa = 5.7 * math.exp(3. * time)
    FileHolder.writelines(str(time) + "\t" + str(x) + "\t" + str(xa) + "\n")
FileHolder.close()

discrepancy = x - xa
print(time, x, xa, discrepancy)
