#include <iostream>
#include <fstream>
#include <iomanip>      // std::setprecision
#include <cmath>

using namespace std;

int main() {
    const int m = 3000;
    const double dt = 0.0001;
    int i;
    double time, discrepancy, xa, x, k1, k2, k3, k4;

    x = 5.7;
    time = 0.0;

    ofstream outfile("rk4.dat");
    for (i = 2; i <= m; i++) {
        time += dt;
        k1 = 3.0 * x;
        k2 = 3.0 * (x + dt * k1 / 2.0);
        k3 = 3.0 * (x + dt * k2 / 2.0);
        k4 = 3.0 * (x + dt * k3);
        x += dt * (k1 + 2.0 * k2 + 2.0 * k3 + k4) / 6.0;
        xa = 5.7 * exp(3.0 * time);
        outfile << setprecision(15) << time << " " << setprecision(15) << x << " " << setprecision(15) << xa << "\n";
    }

    discrepancy = x - xa;
    cout << time << " " << x << " " << xa << " " << discrepancy << endl;
    outfile.close();
    return 0;
}
