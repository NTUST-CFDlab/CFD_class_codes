program RK4
implicit none
integer, parameter :: m = 3000
integer :: i
double precision, parameter :: dt = 0.0001d0
double precision :: time, discrepancy, xa
double precision :: x, k1, k2, k3, k4


x=5.7d0


time=0.0d0
open(unit=11, file='rk4.dat')

do i = 1, m
   time=time+dt
   k1=3.0d0*x
   k2=3.0d0*(x+dt*k1/2.0d0)
   k3=3.0d0*(x+dt*k2/2.0d0)
   k4=3.0d0*(x+dt*k3)
   x=x+dt*(k1+2.0d0*k2+2.0d0*k3+k4)/6.0d0
   xa=5.7d0*exp(3.0d0*time)
   write(11,*)time, x, xa
end do

discrepancy=x-xa
write(*,*)time,x, xa, discrepancy
close(11)
end program RK4