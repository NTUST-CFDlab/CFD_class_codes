Serial

GNU compilers: 		g++ -O2 <filename.cpp> -o <EXEname>

INTEL compilers: 	icpx -O2 <filename.cpp> -o <EXEname>

NVIDIA HPC compilers: 	nvc++ -O2 <filename.cpp> -o <EXEname>
