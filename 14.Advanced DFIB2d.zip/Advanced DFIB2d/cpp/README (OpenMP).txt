OpenMP_CPU

GNU compilers: 		g++ -O2 -fopenmp <filename.cpp> -o <EXEname>

INTEL compilers: 	icpx -O2 -qopenmp <filename.cpp> -o <EXEname>

NVIDIA HPC compilers: 	nvc++ -O2 -mp=multicore <filename.cpp> -o <EXEname>
