Serial

GNU compilers: 		gfortran -O2 <filename.f90> -o <EXEname>

INTEL compilers: 	ifx -O2 <filename.f90> -o <EXEname>

NVIDIA HPC compilers: 	nvfortran -O2 <filename.f90> -o <EXEname>
