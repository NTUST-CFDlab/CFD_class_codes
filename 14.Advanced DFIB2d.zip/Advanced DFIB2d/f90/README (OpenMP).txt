OpenMP_CPU

GNU compilers: 		gfortran -O2 -fopenmp <filename.f90> -o <EXEname>

INTEL compilers: 	ifx -O2 -qopenmp <filename.f90> -o <EXEname>

NVIDIA HPC compilers: 	nvfortran -O2 -mp=multicore <filename.f90> -o <EXEname>
