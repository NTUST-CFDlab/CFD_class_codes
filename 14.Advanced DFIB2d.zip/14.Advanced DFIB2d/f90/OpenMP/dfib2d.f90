MODULE VARIABLES
IMPLICIT NONE
DOUBLE PRECISION :: t1,t2
DOUBLE PRECISION :: CLOCK
INTEGER			 :: nthreads
INTEGER, PARAMETER :: N=256,M=254 
DOUBLE PRECISION :: X(-1:N+2),Y(-1:M+2)
DOUBLE PRECISION :: U(-1:N+2,-1:M+2)
DOUBLE PRECISION :: V(-1:N+2,-1:M+2)
DOUBLE PRECISION :: U1(-1:N+2,-1:M+2),U2(-1:N+2,-1:M+2) 
DOUBLE PRECISION :: V1(-1:N+2,-1:M+2),V2(-1:N+2,-1:M+2) 
DOUBLE PRECISION :: UN1(-1:N+2,-1:M+2)
DOUBLE PRECISION :: VN1(-1:N+2,-1:M+2)
DOUBLE PRECISION :: PRES(-1:N+2,-1:M+2)
DOUBLE PRECISION :: ST(-1:N,-1:M),VORT(-1:N,-1:M)
DOUBLE PRECISION :: FUU(-1:N+2,-1:M+2),FVV(-1:N+2,-1:M+2)
DOUBLE PRECISION :: FUUN1(-1:N+2,-1:M+2),FVVN1(-1:N+2,-1:M+2)
DOUBLE PRECISION :: FUUN2(-1:N+2,-1:M+2),FVVN2(-1:N+2,-1:M+2)
DOUBLE PRECISION :: DP(-1:N+2,-1:M+2)
DOUBLE PRECISION :: DX(-1:N+2),DX1(-1:N+2)
DOUBLE PRECISION :: DY(-1:M+2),DY1(-1:M+2)
DOUBLE PRECISION :: RE,DT,OMEGA,TIME
DOUBLE PRECISION :: PI  
INTEGER :: TTT,OT,FT,RERUN,REIT,ITER
END MODULE VARIABLES




MODULE IBM 
USE VARIABLES
IMPLICIT NONE
DOUBLE PRECISION :: Fx(-1:N+2,-1:M+2),Fy(-1:N+2,-1:M+2)  
DOUBLE PRECISION :: totalFx, totalFy, cDrag, cLift                         
DOUBLE PRECISION :: ETA(0:N+1,0:M+1)
DOUBLE PRECISION :: XX, YY, XC_t, YC_t
DOUBLE PRECISION :: USOLID1,VSOLID1
DOUBLE PRECISION :: USOLID=0.D0	, VSOLID=0.D0			! Impossed solid velocity
DOUBLE PRECISION :: XC = 12.0,YC = 18.0   				! Initial solid reference position for moving solid

END MODULE IBM




PROGRAM DFIB2D
!
!       THIS PROGRAM IS FOR SOLVING UNIFORM FLOW PAST A SQUARE CYLINDER 
!       USING SOLA METHOD
!       
!       AUTHOR: M. J. CHERN   DATE:4 JULY,2001
!       
!       
!       STAGGERED GRID (MAC)
!
!       NON-UNIFORM GRID VERSION 
!       DATE: 14 MAY, 2002
!	
!
!       QUICK SCHEME
!       DATE: 18 SEPT., 2002
!
!
!       PROGRAM MODIFIED FOR AN OSCIALLATING FLOW PAST A SQUARE CYLINDER
!       DATE: 26 OCt. 2002
!
!       MODIFY BOUNDARY CONDITIONS 
!       DATE: 26 Nov. 2002
!
!       CONVERT TO FORTRAN 90 FORMAT
!       DATE: 20 SEPTEMBER 2011
!
!       NATURAL CONVECTION
!       DATE: 4 JAN. 2015
!
!       SOLA METHOD IS REPLACED BY PROJECTION METHOD
!       DATE: 14 MAY, 2015
!
!
!------------------- MODIFIED BY FANDI --------------------
!
!		ENHANCED VOS FUNCTION TO CREATE MANY SHAPES BASED ON
!		AREA FUNCTION (F(X,Y) .LE. 0), OR SYSTEM OF INEQUALITIES.
!		DATE: 20 MAY, 2023
!		
!		IMPOSED SOLID MOTION
!		DATE: 20 MAY, 2023
!
!		PARALLELIZATION USING OPENMP AND CHANGE SOR TO RB-SOR
!		DATE: 08 MAR, 2025
!
!
!------------------- MODIFIED BY FANDI --------------------


USE VARIABLES
USE IBM
USE omp_lib
IMPLICIT NONE

   nthreads = 4 !(OpenMP or OpenACC)
   
   !---------------------------- OPENMP ----------------------------!
   call omp_set_num_threads(nthreads)
   !----------------------------------------------------------------!

!
!       INPUT DATA OF THE FUNCTION U(X,Y) ON COLLOCATION POINTS
 OPEN(UNIT=43,FILE='CLOCK.DAT')
  
	t1 = omp_get_wtime()


	CALL INPUT
	PRINT *,'INPUT PASS'

    CALL VOS
    CALL SOLVER  

    t2 = omp_get_wtime()
    WRITE(43,*) 'Elapsed wall-clock time: ',t2-t1,'seconds'
    PRINT *,'SOLVER PASS'


CONTAINS
!-------------------------------------------------------------
!
!	X(1)=0 |---------------------------| X(N+1)=LENGTH
!
	SUBROUTINE INPUT
	USE VARIABLES
	USE IBM
    IMPLICIT NONE
	INTEGER :: I,J

	PI=DACOS(-1.D0)
	TIME=0.D0 

	OPEN(UNIT=15,FILE='XX.DAT')
        DO I=1,N+1,1
           READ(15,*)X(I)
        END DO
	CLOSE(15)
	
	OPEN(UNIT=16,FILE='YY.DAT')
        DO J=1,M+1,1
           READ(16,*)Y(J)
        END DO
	CLOSE(16)


!	DEFINE EACH OF THE DIRECTIONAL GRID LENGTHS
        DO I=1,N,1
		   DX(I)=X(I+1)-X(I)
        END DO

        DO I=1,N-1,1
           DX1(I)=0.5*(X(I+2)-X(I))
        END DO

        DO J=1,M,1
           DY(J)=Y(J+1)-Y(J)
        END DO
		
        DO J=1,M-1,1
           DY1(J)=0.5*(Y(J+2)-Y(J))
        END DO	

!	LENGTH OF GHOST CELLS

		DX(0)   = DX(1)
		DX(-1)  = DX(1)
		DX1(0)  = DX1(1)
		DX1(-1) = DX1(1)

		DY(0)   = DY(1)		
		DY(-1)  = DY(1)
		DY1(0)  = DY1(1)
		DY1(-1) = DY1(1)
		
		DX(N+1) = DX(N)
		DX(N+2) = DX(N)
		DX1(N)  = DX1(N-1)
		DX1(N+1)= DX1(N-1)

		DY(M+1) = DY(M)		
		DY(M+2) = DY(M)
		DY1(M)  = DY1(M-1)
		DY1(M+1)= DY1(M-1)


	    OPEN(UNIT=19,FILE='PARA.F')
        READ(19,*)TTT,OT,DT,FT,ITER,RE,OMEGA,RERUN
	CLOSE(19)
	
		TIME=0.D0 
		
!	INITIAL CONDITIONS		
	DO I=-1,N+2,1
	   DO  J=-1,M+2,1
           U(I,J)=1.D0
		   V(I,J)=0.D0
		   PRES(I,J)=0.D0   
       END DO
    END DO
	
	RETURN
	END SUBROUTINE INPUT
!-------------------------------------------------------------



	SUBROUTINE BOUNDARY
	USE VARIABLES
    IMPLICIT NONE
	INTEGER :: I,J


!       DEFINE U(0,Y),V(0,Y)

	!$OMP PARALLEL
	!$OMP DO
	DO J=-1,M+2,1							! left
		U(0,J)=1.D0
        U(-1,J)=U(0,J)
		V(0,J)=-V(1,J)
        V(-1,J)=V(0,J)		
    END DO
	!$OMP END DO


!       DEFINE U(N,Y),V(N,Y)
	!$OMP DO
	DO J=-1,M+2,1							! right
		U(N,J)=U(N-1,J)
		U(N+1,J)=U(N,J)
		U(N+2,J)=U(N+1,J)
		V(N+1,J)=V(N,J)
		V(N+2,J)=V(N+1,J)
	END DO
	!$OMP END DO
	!$OMP END PARALLEL

!       DEFINE U(X,0),V(X,0)

    !$OMP PARALLEL
	!$OMP DO
	DO I=-1,N+2,1							! bottom
        U(I,0)=U(I,1)
        U(I,-1)=U(I,0)
        V(I,0)=0.D0
        V(I,-1)=V(I,0)
    END DO
	!$OMP END DO


!       DEFINE U(X,M),V(X,M)

	!$OMP DO
	DO I=-1,N+2,1							! top
        U(I,M+1)=U(I,M)
        U(I,M+2)=U(I,M+1)
        V(I,M)=0.D0						
        V(I,M+1)=V(I,M)
        V(I,M+2)=V(I,M+1)	
    END DO
	!$OMP END DO
	!$OMP END PARALLEL


	RETURN
	END SUBROUTINE BOUNDARY


!-------------------------------------------------------------


	SUBROUTINE PRESSURE_BOUNDARY
	USE VARIABLES
	IMPLICIT NONE
	INTEGER :: I,J

    !$OMP PARALLEL DO
	DO J=0,M+1,1
	PRES(0,J)=PRES(1,J)
	PRES(N+1,J)=PRES(N,J)
	END DO
	!$OMP END PARALLEL DO 

	!$OMP PARALLEL DO 
	DO I=0,N+1,1
	PRES(I,0)=PRES(I,1)
	PRES(I,M+1)=PRES(I,M)    	
	END DO
	!$OMP END PARALLEL DO 


	RETURN
	END SUBROUTINE PRESSURE_BOUNDARY

!-------------------------------------------------------------


    SUBROUTINE VOS
   
    USE VARIABLES
    USE IBM
    IMPLICIT NONE
    INTEGER :: I,J, II, JJ
    DOUBLE PRECISION :: SUBDX, SUBDY
    DOUBLE PRECISION :: X_sub,Y_sub
    DOUBLE PRECISION :: SUBX(101), SUBY(101)
    DOUBLE PRECISION :: circle,moving_circle,moving_rectangle
      
    OPEN(UNIT=88,FILE='ETA.dat')

     WRITE(88,*) 'VARIABLES=X,Y,ETA'
     WRITE(88,*) 'ZONE I=',N,',J=',M,' F=POINT'
      
	  
! 	Update XC and YC
	!XC_t = XC + USOLID*TIME			! For a moving solid
	!YC_t = YC + VSOLID*TIME			! For a moving solid

	
!	Creating binary ETA (only 0 or 1)

	!$OMP PARALLEL DO PRIVATE(I,X_sub,Y_sub) collapse(2)     
       DO  J=1,M,1
         DO  I=1,N,1
			X_sub = 0.5d0*(X(I)+X(I+1))
			Y_sub = 0.5d0*(Y(J)+Y(J+1))

!		    Input a function or a system of inequalities f(X_sub-XC,Y_sub-YC)				<----------------- VOS FUNCTION
			IF( (X_sub - XC)**2 + (Y_sub - YC)**2 .LE. 0.5d0**2 ) THEN
				ETA(I,J)=1.D0
			ELSE
				ETA(I,J)=0.D0		
			ENDIF
       END DO
       END DO
	!$OMP END PARALLEL DO

!	Creating subgrids
	!$OMP PARALLEL DO PRIVATE(I,II,JJ,SUBDX,SUBDY,SUBX,SUBY,X_sub,Y_sub) collapse(2)
       DO  J=1,M,1
         DO  I=1,N,1
!		 Finding potential grids for subgrids
		IF (ANY(ETA(I,J) /= ETA(I-1:I+1, J-1:J+1))) THEN
					SUBDX = (X(I+1)-X(I))/100.0
					SUBDY = (Y(J+1)-Y(J))/100.0		
                  DO II = 1, 101
                    SUBX(II)=X(I) + (II-1)*SUBDX
                  END DO  
                  DO JJ = 1, 101
                    SUBY(JJ)=Y(J) + (JJ-1)*SUBDY
                  END DO

                  ETA(I,J)=0.D0
                  DO II = 1, 100
                    DO JJ = 1, 100
					  X_sub = 0.5d0*(SUBX(II)+SUBX(II+1))
					  Y_sub = 0.5d0*(SUBY(JJ)+SUBY(JJ+1))

!					  Use the same function as used in binary ETA f(X_sub-XC,Y_sub-YC)		<----------------- VOS FUNCTION
                      IF( (X_sub - XC)**2 + (Y_sub - YC)**2 .LE. 0.5d0**2 ) THEN 			  
						ETA(I,J)=ETA(I,J)+1.0
					  ENDIF
                    END DO  
                  END DO 
				  
                  ETA(I,J)=ETA(I,J)/10000.0  
            ENDIF  
            WRITE(88,*) 0.5*(X(I)+X(I+1)),0.5*(Y(J)+Y(J+1)),ETA(I,J)   
           
       END DO
       END DO
	!$OMP END PARALLEL DO          

        CLOSE(88)
	    RETURN
	  END SUBROUTINE VOS		
	


!----------------------LIST OF FUNCTION SUBROUTINES FOR VOS------------------------------------------------     
 

	! FUNCTION circle(xf,yf) result(circ)
	! USE IBM
	! IMPLICIT NONE
	! double precision , intent(in) :: xf,yf
	! double precision :: center_x,center_y,radius,circ
	
	! center_x = 10.0
	! center_y = 10.0
	! radius = 0.5d0
	
	! circ = (xf - center_x)**2 + (yf - center_y)**2 - radius**2

	! END FUNCTION circle

!---------------------------------------------------------------------------------------------------------
 
	! FUNCTION moving_circle(xf,yf) result(circ)
	! USE IBM
	! IMPLICIT NONE
	! double precision , intent(in) :: xf,yf
	! double precision :: radius,circ

	! radius = 0.5d0
	
	! circ = (xf - XC_t)**2 + (yf - YC_t)**2 - radius**2

	! END FUNCTION moving_circle
 
!---------------------------------------------------------------------------------------------------------

	! FUNCTION moving_rectangle(xf,yf) result(rect)
	! USE IBM
	! IMPLICIT NONE
	! double precision , intent(in) :: xf,yf
	! double precision :: length,width,ALPHA,rect

	! length= 48.6d0
	! width = 2.1d0
	! ALPHA = -13.85d0*PI/180

	! XX = (xf - XC_t)*COS(ALPHA) - (yf - YC_t)*SIN(ALPHA)
	! YY = (yf - YC_t)*COS(ALPHA) + (xf - XC_t)*SIN(ALPHA)
	
	! rect = (ABS(XX/(width/length) + YY) + ABS(XX/(width/length) - YY)) - 1.d0 

	! END FUNCTION moving_rectangle 


!---------------------------------------------------------------------------------------------------------
!
!
!
    SUBROUTINE QUICK
    USE VARIABLES
    IMPLICIT NONE
    DOUBLE PRECISION :: FUX,FUY,FUC,FVX,FVY,FVC
    DOUBLE PRECISION :: VISX,VISY,VDX,VDY
    DOUBLE PRECISION :: UE,UE1,UNN,UW,UW1,US1
    DOUBLE PRECISION :: VN,VE1,VNN,VS,VW1,VS1
    INTEGER :: I,J

	!$OMP PARALLEL DO PRIVATE(J,UE,UW,VN,VS,UE1,UW1,UNN,US1,FUX,FUY,VDX,VDY,VISX) collapse(2)
    DO  I=1,N,1
    DO  J=1,M,1            
      UE = 0.5D0 * (U(I+1,J)+U(I,J)) 
      UW = 0.5D0 * (U(I-1,J)+U(I,J))
      VN = 0.5D0 * (V(I,J)+V(I+1,J))
      VS = 0.5D0 * (V(I,J-1)+V(I+1,J-1))


        IF (UE > 0) THEN 

        UE1 = 0.5D0*(U(I,J)     + U(I+1,J)  ) -0.125D0*DX(I+1)*DX(I+1)/DX1(I)* &
				(  (U(I+1,J)   - U(I,J)    ) / DX(I+1) &
				 - (U(I,J)     - U(I-1,J)  ) / DX(I)   )
                
        ELSE

        UE1 = 0.5D0*(U(I,J)     + U(I+1,J)  ) -0.125D0*DX(I+1)*DX(I+1)/DX1(I+1)* &
				(  (U(I+2,J)   - U(I+1,J)  ) / DX(I+2) &
				 - (U(I+1,J)   - U(I,J)    ) / DX(I+1) )

        END IF

        IF (UW > 0) THEN 

        UW1 = 0.5D0*(U(I-1,J)   + U(I,J)    ) -0.125D0*DX(I)*DX(I)/DX1(I-1)* &
				(  (U(I,J)     - U(I-1,J)  ) / DX(I)   &
				 - (U(I-1,J)   - U(I-2,J)  ) / DX(I-1) ) 
                
        ELSE

        UW1 = 0.5D0*(U(I-1,J)   + U(I,J)    ) -0.125D0*DX(I)*DX(I)/DX1(I)* &
				(  (U(I+1,J)   - U(I,J)    ) / DX(I+1) &
				 - (U(I,J)     - U(I-1,J)  ) / DX(I)   ) 

        END IF

        IF (VN > 0) THEN 

        UNN = 0.5D0*(U(I,J)     + U(I,J+1)  ) -0.125D0*DY1(J)*DY1(J)/DY(J)* &
				(  (U(I,J+1)   - U(I,J)    ) / DY1(J)  &
				 - (U(I,J)     - U(I,J-1)  ) / DY1(J-1))  
                
        ELSE

        UNN = 0.5D0*(U(I,J)     + U(I,J+1) )-0.125D0*DY1(J)*DY1(J)/DY(J+1)* &
				(  (U(I,J+2)   - U(I,J+1)  ) / DY1(J+1)&
				 - (U(I,J+1)   - U(I,J)    ) / DY1(J)  )

        END IF

        IF (VS > 0) THEN 

        US1 = 0.5D0*(U(I,J-1)   + U(I,J)    ) -0.125D0*DY1(J-1)*DY1(J-1)/DY(J-1)* &
				(  (U(I,J)     - U(I,J-1)  ) / DY1(J-1)&
				 - (U(I,J-1)   - U(I,J-2)  ) / DY1(J-2)) 
                
        ELSE

        US1 = 0.5D0*(U(I,J-1)   + U(I,J)    ) -0.125D0*DY1(J-1)*DY1(J-1)/DY(J)* &
				(  (U(I,J+1)   - U(I,J)    ) / DY1(J)  &
				 - (U(I,J)     - U(I,J-1)  ) / DY1(J-1))  

        END IF

		FUX=(UE*UE1-UW*UW1) / DX1(I)
		FUY=(VN*UNN-VS*US1) / DY(J)
		VDX=( (U(I+1,J)-U(I,J)) / DX(I+1) - (U(I,J)-U(I-1,J)) / DX(I) ) / DX1(I)
		VDY=( (U(I,J+1)-U(I,J)) / DY1(J) - (U(I,J)-U(I,J-1)) / DY1(J-1) ) / DY(J)
        VISX=(VDX+VDY)/RE
		
        FUU(I,J)=DT*(-FUX-FUY+VISX)
		
	 END DO
    END DO   
	!$OMP END PARALLEL DO 

	!$OMP PARALLEL DO PRIVATE(J,UE,UW,VN,VS,VE1,VW1,VNN,VS1,FVX,FVY,VDX,VDY,VISY) collapse(2)
    DO  I=1,N,1
     DO  J=1,M,1             
      UE = 0.5D0 * (U(I,J)+U(I,J+1))
      UW = 0.5D0 * (U(I-1,J)+U(I-1,J+1))
      VN = 0.5D0 * (V(I,J)+V(I,J+1))
      VS = 0.5D0 * (V(I,J-1)+V(I,J))

        IF (UE > 0) THEN 
        
        VE1 = 0.5D0*(V(I,J)     + V(I+1,J)  ) -0.125D0*DX1(I)*DX1(I)/DX(I)* &
				(  (V(I+1,J)   - V(I,J)    ) / DX1(I)  &
				 - (V(I,J)     - V(I-1,J)  ) / DX1(I-1))

        ELSE

        VE1 = 0.5D0*(V(I,J)     + V(I+1,J)  ) -0.125D0*DX1(I)*DX1(I)/DX(I+1)* &
				(  (V(I+2,J)   - V(I+1,J)  ) / DX1(I+1)&
				 - (V(I+1,J)   - V(I,J)    ) / DX1(I)  )  

        END IF

        IF (UW > 0) THEN 

        VW1 = 0.5D0*(V(I-1,J)   + V(I,J)    ) -0.125D0*DX1(I-1)*DX1(I-1)/DX(I-1)* &
				(  (V(I,J)     - V(I-1,J)  ) / DX1(I-1)&
				 - (V(I-1,J)   - V(I-2,J)  ) / DX1(I-2)) 

        ELSE 

        VW1 = 0.5D0*(V(I-1,J)   + V(I,J)    ) -0.125D0*DX1(I-1)*DX1(I-1)/DX(I)* &
				(  (V(I+1,J)   - V(I,J)    ) / DX1(I)  &
				 - (V(I,J)     - V(I-1,J)  ) / DX1(I-1))  

        END IF

        IF (VN > 0) THEN 

        VNN = 0.5D0*(V(I,J)     + V(I,J+1)  ) -0.125D0*DY(J+1)*DY(J+1)/DY1(J)* &
				(  (V(I,J+1)   - V(I,J)    ) / DY(J+1) &
				 - (V(I,J)     - V(I,J-1)  ) / DY(J)   ) 
            
        ELSE

        VNN = 0.5D0*(V(I,J)     + V(I,J+1)  ) -0.125D0*DY(J+1)*DY(J+1)/DY1(J+1)* &
				(  (V(I,J+2)   - V(I,J+1)  ) / DY(J+2) &
				 - (V(I,J+1)   - V(I,J)    ) / DY(J+1) ) 

        END IF

        IF (VS > 0) THEN 

        VS1 = 0.5D0*(V(I,J-1)   + V(I,J)    ) -0.125D0*DY(J)*DY(J)/DY1(J-1)* &
				(  (V(I,J)     - V(I,J-1)  ) / DY(J)   &
				 - (V(I,J-1)   - V(I,J-2)  ) / DY(J-1) ) 
            
        ELSE

		VS1 = 0.5D0*(V(I,J-1)   + V(I,J)    ) -0.125D0*DY(J)*DY(J)/DY1(J)* &
              	(  (V(I,J+1)   - V(I,J)    ) / DY(J+1)&
                 - (V(I,J)     - V(I,J-1)  ) / DY(J)  ) 

        END IF

		FVX=(UE*VE1-UW*VW1)/DX(I) 
        FVY=(VN*VNN-VS*VS1)/DY1(J)
		VDX=( (V(I+1,J)-V(I,J)) / DX1(I) - (V(I,J) - V(I-1,J)) / DX1(I-1) ) / DX(I)
		VDY=( (V(I,J+1)-V(I,J)) / DY(J+1) - (V(I,J) - V(I,J-1)) / DY(J) ) / DY1(J)
        VISY=(VDX+VDY)/RE
		
        FVV(I,J)=DT*(-FVX-FVY+VISY)
             
 	 END DO
 	END DO  
	!$OMP END PARALLEL DO 

       
    RETURN
    END SUBROUTINE QUICK
!-------------------------------------------------------------



	SUBROUTINE SOLVER
	USE VARIABLES
    USE IBM 	

    IMPLICIT NONE
	DOUBLE PRECISION :: TEMP,DMAX,TS
    DOUBLE PRECISION :: UTEMP, VTEMP
    DOUBLE PRECISION :: TOL = 1.0D-3
    DOUBLE PRECISION :: DD, AP, AN, AS, AW, AE
	INTEGER :: TITE
	INTEGER :: I,J,PPPP
	CHARACTER(LEN=11) :: FILENAME,REFILE
  
	FILENAME='CA00000.TEC'  
	REFILE='LAST.DAT'
	
    OPEN(UNIT=26,FILE='flow.dat')
        
	open (31,file='CD_Time.dat',position='append')			! For TECPLOT360
	write(31,*) ' TITLE     = "" '
	write(31,*) ' VARIABLES = t*,C<sub>D</sub>,C<sub>L</sub> '   


	! open (31,file='CD_Time.csv',position='append')		! For CSV/PARAVIEW
	! write(31,*) ' Time,CD,CL ' 
	

	REIT=1
	!$OMP PARALLEL DO collapse(2)
    DO  I=-1,N+2,1
       DO  J=-1,M+2,1
		 UN1(I,J)=U(I,J)
		 VN1(I,J)=V(I,J)
         FUUN1(I,J)=0.D0
         FUUN2(I,J)=0.D0
         FVVN1(I,J)=0.D0
         FVVN2(I,J)=0.D0
         Fx(I,J)=0.D0	
         Fy(I,J)=0.D0	
	   END DO   
	END DO
	!$OMP END PARALLEL DO 
	
	IF (RERUN == 1) THEN												! Calling the last data for RERUN
		OPEN(UNIT=22,FILE=REFILE)
		READ(22,*)TIME
		READ(22,*)REIT
		DO  I=1,N,1
		DO  J=1,M,1
		   READ(22,*)U(I,J),V(I,J),PRES(I,J)  
		END DO
	    END DO
        DO  J=1,M,1
		DO  I=1,N,1
		  READ(22,*)FUUN1(I,J),FUUN2(I,J),FVVN1(I,J),FVVN2(I,J)
        END DO        
        END DO
		CLOSE(22)
        REIT=REIT+1
	ENDIF    

!
!     CONSTRUCTION OF COEFFICIENT MATRIX
!
!
!       LOOP 10 :TIME STEPPING
!
	DO  TITE=REIT,TTT,1
	TIME=TIME+DT
	PRINT *,'TIME =',TIME
    !CALL VOS					! For a moving solid
!
!       SOLVING VELOCITY FIELD
!       USING QUICK SCHEME
!
    CALL QUICK

        !$OMP PARALLEL DO collapse(2)
		DO  I=1,N,1
           DO  J=1,M,1
             IF (REIT == 1) THEN
               U(I,J)=U(I,J)+FUU(I,J)
             ELSE
               IF(REIT == 2) THEN
                 U(I,J)=U(I,J)+1.5*FUU(I,J)-0.5*FUUN1(I,J)
               ELSE
                 U(I,J)=U(I,J)+(23.*FUU(I,J)-16.*FUUN1(I,J)+5.*FUUN2(I,J))/12.
               ENDIF    
             ENDIF    
             FUUN2(I,J)=FUUN1(I,J)
             FUUN1(I,J)=FUU(I,J)
	       END DO   
	    END DO  
        !$OMP END PARALLEL DO 
		
		!$OMP PARALLEL DO collapse(2)
		DO  I=1,N,1
           DO  J=1,M,1 
             IF (REIT == 1) THEN            
		        V(I,J)=V(I,J)+FVV(I,J)
             ELSE
               IF (REIT == 2) THEN
                 V(I,J)=V(I,J)+1.5*FVV(I,J)-0.5*FVVN1(I,J)
               ELSE
                 V(I,J)=V(I,J)+(23.*FVV(I,J)-16.*FVVN1(I,J)+5.*FVVN2(I,J))/12.
               ENDIF    
             ENDIF        
             FVVN2(I,J)=FVVN1(I,J)
             FVVN1(I,J)=FVV(I,J)         
           END DO   
	    END DO
		!$OMP END PARALLEL DO 
		
        CALL BOUNDARY
!
!     U,V,W AND P ---- PREDICTION-CORRECTION
!

	PPPP=0
	DMAX=1.D0

	DO WHILE (DMAX > TOL .AND. PPPP < ITER)
	  
	  PPPP=PPPP+1
	  DMAX=0.D0
	
! Red-Black ordering (RED)
	  !$OMP PARALLEL
	  !$OMP DO PRIVATE(J,DD,AP,AE,AW,AN,AS) REDUCTION(MAX : DMAX) collapse(2)
	  DO  I=1,N,1
	    DO  J=1,M,1             
	      IF (MOD(I+J,2) == 0) THEN
		    DD=(U(I,J)-U(I-1,J))*DY(J)+(V(I,J)-V(I,J-1))*DX(I)
            AP=-DY(J)/DX1(I)-DY(J)/DX1(I-1)-DX(I)/DY1(J)-DX(I)/DY1(J-1)
            AE=DY(J)/DX1(I)
            AW=DY(J)/DX1(I-1)
            AN=DX(I)/DY1(J)
            AS=DX(I)/DY1(J-1)
	        DP(I,J)=-AP*PRES(I,J)-AE*PRES(I+1,J)-AW*PRES(I-1,J)-AN*PRES(I,J+1)-AS*PRES(I,J-1)+DD/DT
            DP(I,J)=DP(I,J)/AP
            PRES(I,J)=PRES(I,J)+OMEGA*DP(I,J)
              
			  DMAX = DMAX1(DABS(DP(I,J)),DMAX)
    	    	
		  ENDIF
	    END DO
      END DO
	  !$OMP END DO 

! Red-Black ordering (BLACK)
	  !$OMP DO PRIVATE(J,DD,AP,AE,AW,AN,AS) REDUCTION(MAX : DMAX) collapse(2)
	  DO  I=1,N,1
	    DO  J=1,M,1             
	      IF (MOD(I+J,2) == 1) THEN
		    DD=(U(I,J)-U(I-1,J))*DY(J)+(V(I,J)-V(I,J-1))*DX(I)
            AP=-DY(J)/DX1(I)-DY(J)/DX1(I-1)-DX(I)/DY1(J)-DX(I)/DY1(J-1)
            AE=DY(J)/DX1(I)
            AW=DY(J)/DX1(I-1)
            AN=DX(I)/DY1(J)
            AS=DX(I)/DY1(J-1)
	        DP(I,J)=-AP*PRES(I,J)-AE*PRES(I+1,J)-AW*PRES(I-1,J)-AN*PRES(I,J+1)-AS*PRES(I,J-1)+DD/DT
            DP(I,J)=DP(I,J)/AP
            PRES(I,J)=PRES(I,J)+OMEGA*DP(I,J)

			  DMAX = DMAX1(DABS(DP(I,J)),DMAX)
			      	
		  ENDIF
	    END DO
      END DO
	  !$OMP END DO 
	  !$OMP END PARALLEL
	  

    END DO

    CALL PRESSURE_BOUNDARY	   
   
!----------------------------------------------------------------------------------------------      Coefficient    Cd,Cl,LW,/R    
	 
		totalFx = 0.d0
		!$OMP PARALLEL DO PRIVATE(J,USOLID1)  reduction(+: totalFx) collapse(2)
          DO  I=1,N,1 
          DO  J=1,M,1              
			U1(I,J)=U(I,J)-DT*(PRES(I+1,J)-PRES(I,J))/DX1(I)
			USOLID1 = USOLID
            U2(I,J)=0.5d0*(ETA(I+1,J)+ETA(I,J)) * USOLID1 + (1.d0 - 0.5d0*(ETA(I+1,J)+ETA(I,J))) * U1(I,J)
            Fx(I,J)=(U2(I,J) - U1(I,J))/DT 
            totalFx=totalFx+(Fx(I,J)*(DX(I)*DY(J)))
			U(I,J)=U2(I,J)
          END DO
          END DO   
		!$OMP END PARALLEL DO 
          
          

		totalFy = 0.d0  
		!$OMP PARALLEL DO PRIVATE(J,VSOLID1)  reduction(+: totalFy) collapse(2)
           DO  I=1,N,1 
           DO  J=1,M,1 
			V1(I,J)=V(I,J)-DT*(PRES(I,J+1)-PRES(I,J))/DY1(J)
			VSOLID1 = VSOLID
            V2(I,J)=0.5d0*(ETA(I,J+1)+ETA(I,J)) * VSOLID1 + (1.d0 - 0.5d0*(ETA(I,J+1)+ETA(I,J))) * V1(I,J)
            Fy(I,J)=(V2(I,J) - V1(I,J))/DT 
            totalFy=totalFy+(Fy(I,J)*(DX(I)*DY(J)))
			V(I,J)=V2(I,J)
           END DO
           END DO
		!$OMP END PARALLEL DO
        
		cDrag = -2.d0 * totalFx		! cDrag = 2*totalFx/(rho * U^2 * D)
		cLift = -2.d0 * totalFY		! cLift = 2*totalFy/(rho * U^2 * D)
		
		IF (TIME .GE. 0.1d0) THEN
			write(31,*) REAL(time),',', REAL(cDrag),',', REAL(cLift)
		ENDIF


       CALL BOUNDARY              
         
!---------------------------------------------------------------------------------------------



    TEMP=0.D0   
    TS=0.D0
	!$OMP PARALLEL DO PRIVATE(J,UTEMP,VTEMP)  REDUCTION(+: TS) REDUCTION(MAX: TEMP) collapse(2)
	DO  I=-1,N+2,1
	   DO  J=-1,M+2,1
		 UTEMP=DABS(U(I,J)-UN1(I,J))
		 VTEMP=DABS(V(I,J)-VN1(I,J))
		 TS=TS+UTEMP*UTEMP+VTEMP*VTEMP
		 TEMP = DMAX1(UTEMP,VTEMP,TEMP)
		 UN1(I,J)=U(I,J)
		 VN1(I,J)=V(I,J)         
       END DO
    END DO   
	!$OMP END PARALLEL DO
	
      TS=SQRT(TS/2./(N+1)/(M+1))
      WRITE(*,*)'UV-P ITERATION NUMBER =',PPPP
      WRITE(*,*)'DMAX= ',DMAX
      !WRITE(*,*)'THE MAX. VARIATION=', TEMP,' ,SQRT OF VARIATION=',TS
      WRITE(*,*)' '
      IF (MOD(TITE,FT) == 0) THEN
         WRITE(26,'(I7,F8.2,I6,2(E16.7))')TITE,TIME,PPPP,TEMP,TS
      ENDIF
!
!     OUTPUT NUMERICAL RESULTS
!
		IF (MOD(TITE,OT) == 0) THEN
                WRITE(FILENAME(3:7),'(I5)')TITE/OT
                IF(TITE/OT .LT. 10)   FILENAME(3:6)='0000'
                IF(TITE/OT .LT. 100)  FILENAME(3:5)='000'
                IF(TITE/OT .LT. 1000) FILENAME(3:4)='00'
                IF(TITE/OT .LT. 10000)FILENAME(3:3)='0'

		OPEN(UNIT=20,FILE=FILENAME)
                 !$OMP PARALLEL DO COLLAPSE(2)
				 DO I=0,N,1
                    DO J = 0,M,1
                      ST(I,J)=0.D0
                      VORT(I,J)=0.D0
                    END DO
                 END DO
				 !$OMP END PARALLEL DO
                 
				 !$OMP PARALLEL DO PRIVATE(J) COLLAPSE(2)
				 DO I=1,N-1,1
                   DO J=1,M-1,1
                      ST(I,J)=ST(I,J-1)+(Y(J+1)-Y(J))*U(I,J)
                      VORT(I,J)=-(U(I-1,J)-U(I-1,J-1))/(0.5*(Y(J+1)-Y(J-1)))+(V(I,J-1)-V(I-1,J-1))/(0.5*(X(I+1)-X(I-1)))
                   END DO
                 END DO
                 !$OMP END PARALLEL DO
				 WRITE(20,*)'TITLE="FLOW PAST A CYLINDER"'
                 WRITE(20,*)'VARIABLES=X,Y,ETA,U,V,P,Fx,Fy,ST,VORT'
                 WRITE(20,*)'ZONE T="FLOW", I=',N,' , J=',M,' F=POINT'
                 WRITE(20,*)'SOLUTIONTIME=',TIME				 

		DO  J=1,M,1
		DO  I=1,N,1  
		  WRITE(20,98) 0.5*(X(I)+X(I+1)),0.5*(Y(J)+Y(J+1)),ETA(I,J),0.5*(U(I,J)+U(I-1,J)),0.5*(V(I,J)+V(I,J-1)), &
							   PRES(I,J),0.5*(Fx(I,J)+Fx(I-1,J))   ,0.5*(Fy(I,J)+Fy(I,J-1)),ST(I,J),VORT(I,J)
98        FORMAT(10(E15.7,1X))
        END DO
        END DO

		OPEN(UNIT=21,FILE=REFILE)							! Saving the last data for RERUN
		WRITE(21,*)TIME
		WRITE(21,*)TITE
		DO  I=1,N,1
		DO  J=1,M,1
		  WRITE(21,*)U(I,J),V(I,J),PRES(I,J)
        END DO        
        END DO
        DO  J=1,M,1
		DO  I=1,N,1
		  WRITE(21,*)FUUN1(I,J),FUUN2(I,J),FVVN1(I,J),FVVN2(I,J)
        END DO        
        END DO
	
		CLOSE(21)
		CLOSE(20)
	ENDIF
    END DO
    
    CLOSE(26)
	RETURN
	END SUBROUTINE SOLVER       
	
END PROGRAM DFIB2D
