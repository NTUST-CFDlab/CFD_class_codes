#include <iostream>
#include <fstream>

using namespace std;

const int N = 400;
const int M = 200;

double X[N+2], Y[M+2];


void mesh() {
    double LENGTH, HEIGHT, DXX, DYY;
    int I, J;

    LENGTH = 20.0;
    HEIGHT = 10.0;
    DXX = LENGTH / (N * 1.0);
    DYY = HEIGHT / (M * 1.0);

    ofstream XX("XX.DAT");
    for (I = 2; I <= N + 2; I++) {
        X[I] = DXX * (I-2);
        XX << X[I] << " " << I << endl;
    }
    XX.close();

    ofstream YY("YY.DAT");
    for (J = 2; J <= M + 2; J++) {
        Y[J] = DYY * (J-2);
        YY << Y[J] << " " << J << endl;
    }
    YY.close();

    ofstream meshfile("mesh.dat");
    meshfile << "VARIABLES=X,Y" << endl;
    meshfile << "ZONE I=" << N << ", J=" << M << endl;
    for (J = 2; J <= M+2; J++) {
        for (I = 2; I <= N+2; I++) {
            meshfile << X[I] << " " << Y[J] << endl;
        }
    }
    meshfile.close();
}

int main() {
    mesh();
    return 0;
}
